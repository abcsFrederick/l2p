data = matrix(c(0,3,18,125), nrow = 2)
fisher.test(data,alternative="greater")
