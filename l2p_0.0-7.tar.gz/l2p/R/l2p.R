
l2pver <- function()
{
    result = 7.0
    return (result)
}

l2p <- function(a, ...)
{
# Arguments: 
# a : list of gene symbols
    #fpath <- system.file("extdata", "longdata.txt", package="l2p")
    # N.B. , fpath : just need the name of the place where the bin files are
    universe=NULL
    categories=NULL
    custompathways=NULL
    customfile=NULL
    universefile=NULL
    permute=0
    oneside=1
    rawdataframe=0
    args <- list(...)
    if ("categories" %in% names(args))
    {
            categories=args$categories
    }
    if ("universe" %in% names(args))
    {
            universe=args$universe
    }
    if ("custompathways" %in% names(args))
    {
            custompathways=args$custompathways
    }
    if ("customfile" %in% names(args))
    {
            customfile=args$customfile
    }
    if ("universefile" %in% names(args))
    {
            universefile=args$universefile
    }
    if ("permute" %in% names(args))
    {
            permute = 1
    }
    if ("oneside" %in% names(args))
    {
            oneside=args$oneside
    }
    if ("rawdataframe" %in% names(args))
    {
            rawdataframe=args$rawdataframe
    }
    # debug print(args)
    # debug print(args)
    
    RetVec1 = .Call(getNativeSymbolInfo("l2p"), unique(a),categories,universe,custompathways,customfile,universefile,permute,oneside)
    if (rawdataframe == 0)
    { 
#xxx
        tmpv1 = RetVec1[with(RetVec1,order(fdr,pval,-enrichment_score)),]
        tmpv2=tmpv1[tmpv1$enrichment_score > 0 ,]
# RetVec1[] <- lapply(RetVec1, formatC, , format = "f", digits = 5)   dnw
#        for(i in 1:length(tmpv2$pval)){
#cat (tmpv2$pval[i]);
#cat (" ");
#            cbind(formatC(tmpv2$pval[i],format="f",digits = 22))
#cat (tmpv2$pval[i]);
#cat ("\n");
##            formatC(tmpv2$fdr[i],format="f",digits = 5)
##            formatC(tmpv2$encrichment_score[i],format="f",digits = 5)
#        }
      #   tmpv2=format(tmpv2,25.20)
        options(digits=15)
        return(tmpv2)
#RetVec1[j1] <- lapply(RetVec1[j1], formatC, format = "f", digits = 5)
#        tmpv2[j1] = lapply(tmpv2[j1], formatC, format = "f", digits = 15)
    }
    return(RetVec1)
}

l2pgetuniverse <- function(...)
{
    categories=NULL
    args <- list(...)
    if ("categories" %in% names(args))
    {
        categories=args$categories
    }
    RetVec1 = .Call(getNativeSymbolInfo("l2pgetuniverseR"), categories)
    return(RetVec1)
}

l2pgetlongdesc <- function(a)
{
# Arguments: 
# a : accession
    fpath <- system.file("extdata", "longdata.txt", package="l2p")
    RetVec1 = .Call(getNativeSymbolInfo("l2pgetlongdesc"), a,fpath)
    return(RetVec1)
}

l2pgetgenes4acc <- function(a)
{
# Arguments: 
# a : accession
#fpath <- system.file("extdata", "longdata.txt", package="l2p")
    RetVec1 = .Call(getNativeSymbolInfo("l2pgetgenes4acc"), a)
    return(RetVec1)
}

o2o <- function(genes,animal_source,animal_dest)
{
# Arguments:
# genes : list of source gene symbols
    ugenes=unique(genes)
    RetVec2 = .Call(getNativeSymbolInfo("a2afunc"),ugenes,animal_source,animal_dest)
    return(RetVec2 )
}

a2a <- function(genes,animal_source,animal_dest)  # renamed to o2o , leave as convenience funtion
{
    ugenes=unique(genes)
    return(o2o(ugenes,animal_source,animal_dest))
}

#a2amany <- function(genes,animal_source,animal_dest)
#{
## Arguments:
## genes : list of source gene symbols
#    ugenes=unique(genes)
#    RetVec2 = .Call(getNativeSymbolInfo("a2afunc_many"),ugenes,animal_source,animal_dest)
#    return(RetVec2 )
#}

m2h <- function(b)
{
# Arguments:
# b : list of mouse gene symbols
    zz=unique(b)
    RetVec2 = .Call(getNativeSymbolInfo("a2afunc"),zz,"mouse","human")
}




l2pu <- function(a,b)
{
# Arguments: 
# a : list of gene symbols
# b : universe (list of gene symbols)
    return(l2p(intersect(unique(a),unique(b)),universe=b))
}


l2pwcats <- function(a,b)
{
# Arguments: 
# a : list of gene symbols
# b : text of categories
    return(l2p(unique(a),categories=b))
}

l2puwcats<- function(a,b,c)
{
# Arguments: 
# a : list of gene symbols
# b : universe (list of gene symbols)
# d : text of categories
aa=unique(a)
bb=unique(b)
    return(l2p(intersect(unique(aa),unique(bb)),universe=bb,categories=c))
}


l2pcust <- function(a,bb)
{
# Arguments: 
# a : list of gene symbols
# b : custom list
    return(l2p(unique(a),custompathways=bb))
}

