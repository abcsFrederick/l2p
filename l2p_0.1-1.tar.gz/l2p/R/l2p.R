
l2p <- function(a)
{
# Arguments: 
# a : list of gene symbols

fpath <- system.file("extdata", "pathworks.bin", package="l2p")
#print("fpath is ...")
#print(fpath)

# RetVec2 = .C("l2p", a,fpath,iRetVec = numeric(1))[[3]]
RetVec2 = .Call(getNativeSymbolInfo("l2p"), a,fpath)
#RetVec2 = .C("l2p", a,fpath)
return(RetVec2 )
}

