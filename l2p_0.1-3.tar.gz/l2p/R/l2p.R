
l2p <- function(a)
{
# Arguments: 
# a : list of gene symbols
fpath <- system.file("extdata", "pathworks.bin", package="l2p")
RetVec1 = .Call(getNativeSymbolInfo("l2p"), unique(a),fpath)
return(RetVec1)
}

l2pu <- function(a,b)
{
# Arguments: 
# a : list of gene symbols
# b : universe (list of gene symbols)
fpath <- system.file("extdata", "pathworks.bin", package="l2p")
RetVec1 = .Call(getNativeSymbolInfo("l2pu"), unique(a),unique(b),fpath)
return(RetVec1)
}

l2pmsig <- function(a)
{
# Arguments: 
# a : list of gene symbols
fpath <- system.file("extdata", "pathworks.bin", package="l2p")
RetVec1 = .Call(getNativeSymbolInfo("l2pmsig"), unique(a),fpath)
return(RetVec1)
}

l2pumsig <- function(a,b)
{
# Arguments: 
# a : list of gene symbols
# b : universe (list of gene symbols)
fpath <- system.file("extdata", "pathworks.bin", package="l2p")
RetVec1 = .Call(getNativeSymbolInfo("l2pumsig"), unique(a),unique(b),fpath)
return(RetVec1)
}

m2h <- function(b)
{
# Arguments: 
# b : list of mouse gene symbols
zz=unique(b)
RetVec2 = .Call(getNativeSymbolInfo("m2h"),zz)
return(RetVec2 )
}

l2pver <- function()
{
result = 3.0
return (result)
}

