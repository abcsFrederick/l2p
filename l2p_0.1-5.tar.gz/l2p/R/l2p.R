
l2pver <- function()
{
result = 5.0
return (result)
}

m2h <- function(b)
{
# Arguments: 
# b : list of mouse gene symbols
zz=unique(b)
RetVec2 = .Call(getNativeSymbolInfo("m2h"),zz)
return(RetVec2 )
}

l2p <- function(a)
{
# Arguments: 
# a : list of gene symbols
fpath <- system.file("extdata", "pathworks.bin", package="l2p")
    # N.B. , fpath : just need the name of the place where the bin files are
RetVec1 = .Call(getNativeSymbolInfo("l2p"), unique(a),fpath)
return(RetVec1)
}

l2pu <- function(a,b)
{
# Arguments: 
# a : list of gene symbols
# b : universe (list of gene symbols)
fpath <- system.file("extdata", "pathworks.bin", package="l2p")
x=unique(b);
RetVec1 = .Call(getNativeSymbolInfo("l2pu"), intersect(unique(a),x),x,fpath)
return(RetVec1)
}


l2pwcats <- function(a,b)
{
# Arguments: 
# a : list of gene symbols
# b : text of categories
fpath <- system.file("extdata", "pathworks.bin", package="l2p")
RetVec1 = .Call(getNativeSymbolInfo("l2pwcats"), unique(a),b,fpath)
return(RetVec1)
}

l2puwcats<- function(a,b,c)
{
# Arguments: 
# a : list of gene symbols
# b : universe (list of gene symbols)
# d : text of categories
fpath <- system.file("extdata", "pathworks.bin", package="l2p")
aa=unique(a);
bb=unique(b);
# c func is SEXP l2puwcats(SEXP lst, SEXP ulst, SEXP catsarg, SEXP fpath )
RetVec1 = .Call(getNativeSymbolInfo("l2puwcats"), intersect(aa,bb),bb,c,fpath)
return(RetVec1)
}


l2pgetlongdesc<- function(a)
{
# Arguments: 
# a : accession
fpath <- system.file("extdata", "pathworks.bin", package="l2p")
RetVec1 = .Call(getNativeSymbolInfo("l2pgetlongdesc"), a,fpath)
return(RetVec1)
}

l2pgetgenes4acc <- function(a)
{
# Arguments: 
# a : accession
fpath <- system.file("extdata", "pathworks.bin", package="l2p")
RetVec1 = .Call(getNativeSymbolInfo("l2pgetgenes4acc"), a,fpath)
return(RetVec1)
}

l2pcust <- function(a,b,c)
{
# Arguments: 
# a : list of gene symbols
# b : custom list
# b : name of custom pathway 
fpath <- system.file("extdata", "pathworks.bin", package="l2p")
custlist=unique(b);
RetVec1 = .Call(getNativeSymbolInfo("l2pcust"), unique(a),custlist,c,fpath)
return(RetVec1)
}



# l2pmsigwcats<- function(a,b)
# {
# # Arguments: 
# # a : list of gene symbols
# # b : text of categories
# fpath <- system.file("extdata", "pathworks.bin", package="l2p")
# RetVec1 = .Call(getNativeSymbolInfo("l2pmsigwcats"), unique(a),b,fpath)
# return(RetVec1)
# }

# l2pmsigwcatsu<- function(a,b,c)
# {
# # Arguments: 
# # a : list of gene symbols
# # b : universe (list of gene symbols)
# # c : text of categories
# fpath <- system.file("extdata", "pathworks.bin", package="l2p")
# RetVec1 = .Call(getNativeSymbolInfo("l2pmsigwcatsu"), unique(a),unique(b),c,fpath)
# return(RetVec1)
# }
# l2pmsig <- function(a)
# {
# # Arguments: 
# # a : list of gene symbols
# fpath <- system.file("extdata", "pathworks.bin", package="l2p")
# RetVec1 = .Call(getNativeSymbolInfo("l2pmsig"), unique(a),fpath)
# return(RetVec1)
# }
# 
# l2pumsig <- function(a,b)
# {
# # Arguments: 
# # a : list of gene symbols
# # b : universe (list of gene symbols)
# fpath <- system.file("extdata", "pathworks.bin", package="l2p")
# RetVec1 = .Call(getNativeSymbolInfo("l2pumsig"), unique(a),unique(b),fpath)
# return(RetVec1)
# }
