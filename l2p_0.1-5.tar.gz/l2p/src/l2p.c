
/*
vim l2p.c ; gcc -Ofast -Wall -o l2p pathcommon.c l2p.c -lm  ; strip l2p
vim l2p.c ; gcc -O3 -march=native -flto -Wall -o l2p l2p.c -lm
vim l2p.c ; gcc -D_FORTIFY_SOURCE=2 -fstack-protector --param ssp-buffer-size=4 -fPIE -pie -Wl,-z,relro,-z,now -o l2p pathcommon.c l2p.c -lm
vim l2p.c ; gcc -Wall -pg l2p.c -o l2p
#vim l2p.c ; gcc -D_FORTIFY_SOURCE=2 -fstack-protector --param ssp-buffer-size=4 -fPIE -pie -Wl,-z,relro,-z,now (ld -z relro and ld -z now) -o l2p l2p.c -lm

todo:
1) fix output
2) ensembl to

output:
     1  pval
     2  fdr
     3  ratio                      if postive, genes are OVER REPRESENTED, if negative genes are UNDER REPRESENTED
     4  pathwayhitcount            number of genes hit in pathway
     5  numberofgenesin pathway    number of genes in the pathway
     6  inputnumberofgenes         total count of user genes (user input)
     7  genesinpathwaysuniverse    total number of unique genes in all pathways
     8  pathwayaccessionidentifier canonical accession ( if availible, otherwise assigned by us )
     9  category                   KEGG,REACTOME,GO,PANT(=PANTHER),PID=(pathway interaction database)  *was "soruce"*
    10  pathwayname                Name of pathway
    11  pathwaytype genes_space_separated   HUGO genes from user that hit the pathway

    run with gdb

% gdb myprogram
gdb> run params ... < input.txt

    printf "TP53\nPTEN\nAPC\nKRAS\nNRAS\n"  > jokein
    printf "TP53\nPTEN\nAPC\nKRAS\nNRAS\n"  > jokein
    
    gdb ./l2p
    run  -categories=PID,KEGG < jokein
*/

#ifdef L2P_USING_R
#include <R.h>
#include <Rdefines.h>
#endif

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <ctype.h>
#include <math.h>
#include <limits.h>
#include <errno.h>
#include <unistd.h>

#include "pathworks.h"
// #include "pathcommon.c"

int customhitcnt = 0;

static unsigned char *ucz = (void *)0; // space
static int catspat = 0;   // categories pattern   , if 0, use all
static int no_header_flag = 0;
static int precise_flag = 0; // print out more precise pval and fdr (more digits)
static int user_universe_flag = 0;
static struct binpathouttype binpath[MAXBSID];
static int numbinpaths = 0;
static int numusedpaths;
static struct bingenetype bingene[MAXGENE];   // int geneid; char hugo[]; char ensembl[]; int pathcount; int pathplace;
static int numbingenes;
static long int spacesize;
static char fn_pathbin[PATH_MAX];
static char fn_genesbin[PATH_MAX];
static char fn_spacebin[PATH_MAX];
static char universe_file[PATH_MAX];
static int numg = 0; // number of genes in universe  
static char custom_file[PATH_MAX];
static char custom_name[256];
static int customflag = 0; // user custom pathway
static char custom_file[PATH_MAX];
static char exedir[PATH_MAX]; // executable directory 
static char **customlist;
static int numcustom;
static char **userinput;
static int numuserinput;
struct hugo_type *parallel_hugos;  // parallel to bingenes, defined in .h file
struct used_path_type
{
    double pval;
    double fdr;
    double ad; // ratio
    int bpindex; // bpindex to binpath
    int moreinfo;  // for custom track
};
static struct used_path_type usedpaths[MAXBSID]; // has some extra slack for custom pathways


// -- for benjamini hochberg FDR ...
struct ordertype
{
    double val;
    int order;
};

#if WEBASSEMBLY
int cmp_binpath(const void *a, const void *b)
{
    struct used_path_type *aa;
    struct used_path_type *bb;
    aa = (void *)a;
    bb = (void *)b;
    if      (aa->fdr >  bb->fdr) return 1;
    else if (aa->fdr <  bb->fdr) return -1;
    if      (aa->pval >  bb->pval) return 1;
    else if (aa->pval <  bb->pval) return -1;
    if      (aa->ad >  bb->ad) return 1;
    else if (aa->ad <  bb->ad) return -1;
    // if (aa>bb) return 1; else if (aa<bb) return -1;
    return 0;
}
#endif

static int cmp_ordertype_by_val_REV(const void *a, const void *b)
{
    struct ordertype *aa;
    struct ordertype *bb;
    aa = (void *)a;
    bb = (void *)b;
    if      (aa->val <  bb->val) return 1;
    else if (aa->val >  bb->val) return -1;
    // if (aa>bb) return 1; else if (aa<bb) return -1;
    return 0;
}

#if 0
not used
static int cmp_ordertype_by_val(const void *a, const void *b)
{
    struct ordertype *aa;
    struct ordertype *bb;
    aa = (void *)a;
    bb = (void *)b;
    if      (aa->val >  bb->val) return 1;
    else if (aa->val <  bb->val) return -1;
    // if (aa>bb) return 1; else if (aa<bb) return -1;
    return 0;
}
static int cmp_ordertype_by_order_REV(const void *a, const void *b)
{
    struct ordertype *aa;
    struct ordertype *bb;
    aa = (void *)a;
    bb = (void *)b;
    if      (aa->order <  bb->order) return 1;
    else if (aa->order >  bb->order) return -1;
    return 0;
}
#endif

static int cmp_ordertype_by_order(const void *a, const void *b)
{
    struct ordertype *aa;
    struct ordertype *bb;
    aa = (void *)a;
    bb = (void *)b;
    if      (aa->order >  bb->order) return 1;
    else if (aa->order <  bb->order) return -1;
    return 0;
}


#define RDEBUG 0

static void benjaminihochberg(int n,double pvals[], double returnpvals[])
{
#if 0
// here's the code from R that I re-imagined
                   i <- lp:1L
                   o <- order(p, decreasing = TRUE)
                   ro <- order(o)
                   pmin(1, cummin( n / i * p[o] ))[ro]
#endif
    int j,k;
    struct ordertype *i;
    struct ordertype *o;
    struct ordertype *po;
    struct ordertype *cummin;
//    struct ordertype *ro;
//    struct ordertype *intermed;

    i = (struct ordertype *)malloc((sizeof(struct ordertype))*n);
    for (k=n,j=0;j<n;j++,k--) (i+j)->order=k;

#if RDEBUG
FILE *fp;
fp = fopen("test.pvals","w");
#endif
    o = (struct ordertype *)malloc((sizeof(struct ordertype))*n);
    for (j=0 ; j<n ; j++)
    {
#if RDEBUG
fprintf(fp,"%20.18f\n",pvals[j]);
#endif
        (o+j)->val=pvals[j];
        (o+j)->order=j+1;
    }
#if RDEBUG
fclose(fp);
#endif
    qsort(o,n,sizeof(struct ordertype),cmp_ordertype_by_val_REV);

#if 0
    ro = (struct ordertype *)malloc((sizeof(struct ordertype))*n);
    for (j=0;j<n;j++)
    {
        (ro+j)->val = (double)(o+j)->order;
        (ro+j)->order = j+1;
    }
    qsort(ro,n,sizeof(struct ordertype),cmp_ordertype_by_val);
#endif
    po = (struct ordertype *)malloc((sizeof(struct ordertype))*n);
    for (j=0;j<n;j++)
    {
        (po+j)->val = (double)pvals[j];
        (po+j)->order = (o->order); // why the hell isn't this ro? what the what?
    }
    qsort(po,n,sizeof(struct ordertype),cmp_ordertype_by_val_REV); // == p[o]

    cummin = (struct ordertype *)malloc((sizeof(struct ordertype))*n); // holds n / i * po
    for (j=0;j<n;j++)
    {
        (cummin+j)->val = (double)n / (double)(i+j)->order * ((po+j)->val) ;
    }
                   // Rcode: pmin(1, cummin( n / i * p[o] ))[ro]           ******************
    for (j=1;j<n;j++)
    {
        if ((cummin+j)->val > (cummin+j-1)->val)
            (cummin+j)->val = (cummin+j-1)->val;
    }
    for (j=0;j<n;j++)
    {
        if ((cummin+j)->val > 1)
            (cummin+j)->val = 1;
        (cummin+j)->order = (o+j)->order ;
    }
    qsort(cummin,n,sizeof(struct ordertype),cmp_ordertype_by_order);
#if RDEBUG
FILE *fp2;
fp2 = fopen("test.fdrs","w");
#endif
    for (j=0;j<n;j++)
    {
        returnpvals[j] = (cummin+j)->val;
#if RDEBUG
fprintf(fp2,"%20.18f\n",returnpvals[j]);
#endif
    }
#if RDEBUG
fclose(fp2);
#endif
    if (i) free(i);
    if (o) free(o);
    if (po) free(po);
    if (cummin) free(cummin);

    return;
}


static double lngamm(double z)
// Reference: "Lanczos, C. 'A precision approximation
// of the gamma double ', J. SIAM Numer. Anal., B, 1, 86-96, 1964."
// Translation of  Alan Miller's FORTRAN-implementation
// See http://lib.stat.cmu.edu/apstat/245
{
  double x = 0;
  x += 0.1659470187408462e-06/(z+7);
  x += 0.9934937113930748e-05/(z+6);
  x -= 0.1385710331296526    /(z+5);
  x += 12.50734324009056     /(z+4);
  x -= 176.6150291498386     /(z+3);
  x += 771.3234287757674     /(z+2);
  x -= 1259.139216722289     /(z+1);
  x += 676.5203681218835     /(z);
  x += 0.9999999999995183;
//   return(Math.log(x)-5.58106146679532777-z+(z-0.5)*Math.log(z+6.5));
   return(log(x)-5.58106146679532777-z+(z-0.5)*log(z+6.5));
}

static double lnfact(int n)
{
  if(n<=1) return(0);
  return(lngamm(n+1));
}

static double lnbico(int n,int k)
{
  double ret;
  ret =lnfact(n)-lnfact(k)-lnfact(n-k);

  return(ret);
}

static double hyper_323(int n11,int n1_,int n_1,int n)
{
    double d;
    d = lnbico(n1_,n11) + lnbico(n-n1_,n_1-n11) - lnbico(n,n_1);
    d = exp(d);
    return d;
}

static int sn11,sn1_,sn_1,sn;
static double sprob;

static double hyper0(int n11i,int n1_i,int n_1i,int ni)
{

// printf("in hyper0 %d %d %d %d \n",n11i,n1_i,n_1i,ni);
  if(!(n1_i|n_1i|ni))
  {
//printf("in hyper0 NOT %d %d %d %d \n",n11i,n1_i,n_1i,ni);
    if(!(n11i % 10 == 0))
    {
      if(n11i==sn11+1)
      {
        sprob *= ((double)(sn1_-sn11)/(double)(n11i))*((double)(sn_1-sn11)/(double)(n11i+sn-sn1_-sn_1));
        sn11 = n11i;
        return sprob;
      }
      if(n11i==sn11-1)
      {
        sprob *= ((double)(sn11)/(double)(sn1_-n11i))*((double)(sn11+sn-sn1_-sn_1)/(double)(sn_1-n11i));
        sn11 = n11i;
        return sprob;
      }
    }
    sn11 = n11i;
  }
  else
  {
//printf("in hyper0 else %d %d %d %d \n",n11i,n1_i,n_1i,ni);
    sn11 = n11i;
    sn1_=n1_i;
    sn_1=n_1i;
    sn=ni;
  }
// printf("in hyper0 before hyper_323 %d %d %d %d\n",sn11,sn1_,sn_1,sn);
  sprob = hyper_323(sn11,sn1_,sn_1,sn);
// printf("hyper returns sprob = %10.15f after hyper_323\n",sprob);
  return sprob;
}

static double  hyper(int n11)
{
  return(hyper0(n11,0,0,0));
}

static double sleft,sright,sless,slarg;

static double exact(int n11,int n1_,int n_1,int n)
{
  int i,j;
  double p;
  double prob;
  int max=n1_;

// printf("in exact %d %d %d %d \n",n11,n1_, n_1,n);
  if(n_1<max) max=n_1;
  int min = n1_+n_1-n;
  if(min<0) min=0;
  if(min==max)
  {
    sless = 1;
    sright= 1;
    sleft = 1;
    slarg = 1;
    return 1;
  }

  prob=hyper0(n11,n1_,n_1,n);
// printf("in exact prob=%20.17f \n",prob);
  sleft=0;
  p=hyper(min);
  for(i=min+1; p<0.99999999*prob; i++)
  {
    sleft += p;
    p=hyper(i);
  }
  i--;
  if(p<1.00000001*prob) sleft += p;
  else i--;
  sright=0;
  p=hyper(max);
  for(j=max-1; p<0.99999999*prob; j--)
  {
    sright += p;
    p=hyper(j);
  }
  j++;
  if(p<1.00000001*prob) sright += p;
  else j++;
  if(abs(i-n11)<abs(j-n11))
  {
    sless = sleft;
    slarg = 1 - sleft + prob;
  }
  else
  {
    sless = 1 - sright + prob;
    slarg = sright;
  }
  return prob;
}


static double left,right,twotail;
//static int n11old=-1;
//static int n12old=-1;
//static int n21old=-1;
//static int n22old=-1;

static double exact22(int n11_,int n12_,int n21_,int n22_)
{
#if 0
  double prob = 0.0;
  double n11_ = parseInt("0"+n11,10);
  double n12_ = parseInt("0"+n12,10);
  double n21_ = parseInt("0"+n21,10);
  double n22_ = parseInt("0"+n22,10);
   if((n11old==n11_i) && (n12old==n12_) && (n21old==n21_) && (n22old==n22_)) return;
  n11old=n11_;
  n12old=n12_;
  n21old=n21_;
  n22old=n22_;
#endif
  if(n11_<0) n11_ *= -1;
  if(n12_<0) n12_ *= -1;
  if(n21_<0) n21_ *= -1;
  if(n22_<0) n22_ *= -1;

  int n1_ = n11_+n12_;
  int n_1 = n11_+n21_;
  int n   = n11_ +n12_ +n21_ +n22_;

  // prob = exact(n11_,n1_,n_1,n); don't need return value
  ( void ) exact(n11_,n1_,n_1,n);
// printf("prob after exact is  %30.25f\n",prob);

  left    = sless;
  right   = slarg;
  twotail = sleft+sright;
// printf("left=%20.15f right=%20.15f \n",sleft,sright);
  if(twotail>1) twotail=1;

  return twotail;
// printf("%d %d %d %d %12.8f prob=%20.15f twotail=%20.15f\n",(int)n11_, (int)n12_, (int)n21_, (int)n22_, twotail,prob,twotail);
/*
  document.form1.output.value +=
  newline+
  " TABLE = [ " +
  n11_+" , "+
  n12_+" , "+
  n21_+" , "+
  n22_+" ]" + newline +
  "Left   : p-value = "+ left + newline +
  "Right  : p-value = "+ right + newline +
  "2-Tail : p-value = "+ twotail +
  newline +   "------------------------------------------";
*/
}


#if 0
test code
int fish_exact_test()
{
    double d;
// TEST fisher's exact code
    int n11_;double n12_;double n21_;double n22_;

    n11_ = 3;
    n12_ = 40;
    n21_ = 297;
    n22_ = 29960; 

    d = exact22(n11_,n12_,n21_,n22_);
// 3 hits in p53 pathway which has  40 genes ,total 29960 genes , user input 300 genes  
    d = exact22(3,40,297,29960);
    return 0;
}
#endif



static int cmp_hugo(const void *a, const void *b)
{
    return strcmp(((struct hugo_type *)a)->hugo, ((struct hugo_type *)b)->hugo);;
}

static int cmp_bingene(const void *a, const void *b)
{
    if      ( ((struct bingenetype *)a)->geneid < ((struct bingenetype *)b)->geneid ) return -1;
    else if ( ((struct bingenetype *)a)->geneid > ((struct bingenetype *)b)->geneid ) return 1;
    return 0;
}

    

// so we can search by hugo
struct hugo_type *setup_hugo_parallel_to_genebin(int n)
{
    int i;
    size_t sz;
    struct hugo_type *p;

    sz = (size_t)(n*sizeof(struct hugo_type));
    p = (struct hugo_type *)malloc(sz);
    if (!p) { fprintf(stderr,"ERROR: can't malloc in setup_hugo_parallel_to_genebin...()\n"); return (void *)0; }
    for (i=0;i<n;i++)
    {
        (p+i)->hugo = strdup(bingene[i].hugo);
        (p+i)->generec_ptr = &bingene[i]; // from struct bingenetype bingene[MAXGENE];
    }
    qsort(p,n,sizeof(struct hugo_type),cmp_hugo); // rearrange by hugo name for bsearch , keep link to original genebin rec 
#if 0
    fprintf(stderr,"in setuphugo %d \n",n); fflush(stderr); 
    for (i=0;i<n;i++)
    {
         fprintf(stderr,"cmp %s %s [%s] %p\n",(p+i)->hugo,(p+i)->generec_ptr->hugo,bingene[i].hugo,(p+i)->generec_ptr);
    }
// exit(0);
#endif
    return p;
}



static char *type2string(int type)
{
   static char functional_set[] = "functional_set";
   static char pathway  [] = "pathway";  
   static char structural_complex  [] = "structural_complex";  
   static char custom_string  [] = "custom";  
   static char null_info  [] = "NA";  

   if (type == 1) return &functional_set[0]; 
   else if (type == 2) return &pathway[0];
   else if (type == 3) return &structural_complex[0];
   else if (type == 4) return &custom_string[0];
   return &null_info[0];
}


static void do_pvals_and_bh(int ng,int ingenecnt, struct hit_type *hitz_rec)
{
    struct binpathouttype *binpathptr;
    int skip = 1;
    double d;
    double ad;
    int i,j;
    double *pvals;
    double *fdrs;
    unsigned int localhitcnt ;

    pvals = (double *)malloc((size_t)(sizeof (double)*(numbinpaths+1)));     // plus one is for a custom track
    if (!pvals) { fprintf(stderr,"ERROR: can't malloc in do_pvals_and_bh() 1\n"); return; }

    for (numusedpaths=i=0 ; i<numbinpaths ; i++)
    {
        binpathptr = &binpath[i];
        if (binpathptr->category & catspat) skip = 0; 
        else                                skip = 1; 
        if (skip == 1) continue;

        localhitcnt = (hitz_rec+i)->hitcnt;
        if (localhitcnt)
        {
            if (localhitcnt > (unsigned int)binpathptr->numgenes) 
            {
                 fprintf(stderr,"ERROR: more hits than genes (localhitcnt %d > %d for %s)\n", 
				   localhitcnt , (binpath+i)->numgenes,(char *)(ucz+((binpathptr)->accession ) )) ;
                 fprintf(stderr,"details: i=%d , current hits=%u\n", i,localhitcnt); 
                 fflush(stderr);
                 exit(0);
            }
        }
// test ...
//d = exact22(n11_,n12_,n21_,n22_); note:3 hits in p53 pathway which has  40 genes ,total 29960 genes , user input 300 genes 
// d = exact22(3,40,297,29960);
        d = exact22((int)localhitcnt,(binpathptr)->numgenes,ingenecnt,ng);
        ad = ( ((double)localhitcnt/ (double)(binpathptr)->numgenes) - ((double)ingenecnt/(double)ng) );
        *(pvals+numusedpaths) = usedpaths[numusedpaths].pval = d;
        usedpaths[numusedpaths].ad = ad;
        usedpaths[numusedpaths].bpindex = i;
        usedpaths[numusedpaths].moreinfo = 0;
        numusedpaths++;
    }
    if (customflag) 
    {
//  fprintf(stderr,"in do_pvals_and_bh(), customflag = 1 numusedpaths = %d\n",numusedpaths); fflush(stderr);
        binpathptr = &binpath[numbinpaths];
        binpath[numbinpaths].category = CAT_CUSTOM;      // binpath has extra space 
        binpath[numbinpaths].type = 4;
        binpath[numbinpaths].numgenes = numcustom;
        usedpaths[numusedpaths].bpindex = numbinpaths;
        usedpaths[numusedpaths].moreinfo = 1;
	localhitcnt = 0;

//  fprintf(stderr,"zzz numuserinput=%d , numcustom=%d \n",numuserinput,numcustom);
        for (i=0 ; i<numuserinput ; i++)
	{
             for (j=0 ; j<numcustom ; j++)
	     {
		 if (strcmp(*(userinput+i),*(customlist+j))==0) 
		 {
                     localhitcnt++;
//  fprintf(stderr,"in do_pvals_and_bh(), customflag = 1 got hit %s i=%d j=%d\n",*(userinput+i),i,j); fflush(stderr);
		 }
	     }
	}
	customhitcnt = 1;
        d = exact22((int)localhitcnt,(binpathptr)->numgenes,ingenecnt,ng);
        ad = ( ((double)localhitcnt/ (double)(binpathptr)->numgenes) - ((double)ingenecnt/(double)ng) );
        *(pvals+numusedpaths) = usedpaths[numusedpaths].pval = d;
	// zzz 
// fprintf(stderr,"setting hitcnt for custom to %d\n",localhitcnt); fflush(stderr); 
        (hitz_rec+usedpaths[numusedpaths].bpindex)->hitcnt = localhitcnt;
        numbinpaths++;
        numusedpaths++;
    }

    fdrs = (double *)malloc((size_t)(sizeof (double)*numbinpaths)); 
    if (!fdrs) { free(pvals); /* clean up */ fprintf(stderr,"ERROR: can't malloc in do_pvals_and_bh() 2\n"); exit(0); }
    benjaminihochberg(numusedpaths,pvals,fdrs);
    for (i=0 ; i<numusedpaths ; i++)
         usedpaths[i].fdr = *(fdrs+i);
    free(pvals); // path parallel
    free(fdrs);
    return;
}

static void adduserinputgene(char *genename)
{
    static int inited = 0;

    if (!customflag) return;     // only do this if custom ?

    if (inited == 0) 
    {
        numuserinput=0; 
        userinput  = (void *)malloc(sizeof(char *)*MAXGENE);
        inited = 1; 
    }
    *(userinput+numuserinput) = strdup(genename);
    numuserinput++;
// fprintf(stderr,"zzz in adduserinputgene(%s), numuserinput=%d\n",genename,numuserinput); fflush(stderr); 
    return;
}

#ifdef L2P_USING_R

static int R_deal_with_universe_list(SEXP lst, int numbingenes, int numbinpaths, 
                 int *numg_ptr, unsigned char *spaceptr) 
{
    char tmphugo[1024];
    struct hugo_type *hugoptr;
    struct hugo_type h;
    int found = 0;
    int geneid;
    int *iptr;
    int o2g;
    int i,j;
    int n = 0;
    int new_fix_gene_count;
    struct bingenetype Xgenerec; 
    struct bingenetype *Xgenerec_ptr; 

    n = length(lst);

//     fprintf(stderr,"rpf in R_deal_with_universe_list\n"); fflush(NULL); 
    for (i=0;i<numbingenes;i++) parallel_hugos[i].status = 0;  // assume "guilty"
    for (i=0;i<n;i++) 
    {
        memset(&h,0,sizeof(h));
        h.hugo = strdup(CHAR(STRING_ELT(lst, i)));
        hugoptr = bsearch(&h,parallel_hugos,numbingenes,sizeof(struct hugo_type),cmp_hugo);
        if (hugoptr) hugoptr->status = 1; // "innocent"
        free(h.hugo);
    }
    for (i=0 ; i<numbinpaths ; i++)         // for each pathway
    {
       new_fix_gene_count = binpath[i].numgenes;
       o2g = binpath[i].offset2geneids;
       if (o2g<=0) continue;
       iptr = (int *)(spaceptr + o2g);
       for (j=0 ; j<binpath[i].numgenes ; j++)  // for each gene for this pathway
       {
           geneid = *(iptr+j);
           found = 0;
           // memset(&Xgenerec,0,sizeof(struct bingenetype)); not needed
           Xgenerec.geneid = geneid;
           Xgenerec_ptr = bsearch(&Xgenerec,&bingene[0],numbingenes,sizeof(struct bingenetype),cmp_bingene);
           if (Xgenerec_ptr)
           {
               strcpy(tmphugo, Xgenerec_ptr->hugo);
               h.hugo = &tmphugo[0];
               hugoptr = bsearch(&h,parallel_hugos,numbingenes,sizeof(struct hugo_type),cmp_hugo);
               if (hugoptr)
               {
                   found = 1;
                   if (hugoptr->status == 0) // not in universe
                   {
// fprintf(stderr,"%s removed \n",h.hugo); fflush(stderr);  
                       new_fix_gene_count--;
                   }
               }
           }
           if (found == 0) 
           {
               fprintf(stderr,"Note: Can not find geneid %d in deal with universe\n",geneid); 
               exit(0);
           }
       }
       if (binpath[i].numgenes != new_fix_gene_count)
            binpath[i].numgenes = new_fix_gene_count;
    }
//  fprintf(stderr,"in dealwithunivese R 3\n"); fflush(stderr); 
    j = 0;
    for (i=0 ; i<numbingenes ; i++) 
    {
       if (parallel_hugos[i].status == 1) j++;
    }
// fprintf(stderr,"Setting new universe to new %d ( from old universe  %d )n=%d\n",j,*numg_ptr,n); fflush(stderr);
    *numg_ptr = j;
    return 0;
}

// static int deal_with_custom_file(char custom_fn[],int numbingenes, int numbinpaths, int *numg_ptr, unsigned char *spaceptr, struct hugo_type parah[]) 

#if 0
static int R_deal_with_custom_list(SEXP lst,int numbingenes,int numbinpaths,int *numg_ptr,unsigned char *spaceptr) 
{
    struct hugo_type *hugoptr;
    struct hugo_type h;
    int i,j;
    int n = 0;

//     fprintf(stderr,"rpf in R_deal_with_custom_list\n"); fflush(NULL); 
    n = length(lst);
    j = 0;
    customlist = (void *)malloc(sizeof(char *) * n);
    for (i=0;i<n;i++) 
    {
        memset(&h,0,sizeof(h));
        h.hugo = strdup(CHAR(STRING_ELT(lst, i)));
        hugoptr = bsearch(&h,parallel_hugos,numbingenes,sizeof(struct hugo_type),cmp_hugo);
        if (hugoptr) *(customlist+(j++)) = strdup(h.hugo);
        free(h.hugo);
    }
    numcustom = j;
    return 0;
}
#endif
 
#else
 // raw C version ..

static int deal_with_universe_file(char universe_fn[],int numbingenes, int numbinpaths, int *numg_ptr, unsigned char *spaceptr, struct hugo_type parah[]) 
{
    char s[20000];
    char tmphugo[100];
    int found = 0;
    int geneid;
    int *iptr;
    int o2g;
    int i,j;
    int new_fix_gene_count;
    int errorcode;
    FILE *fp;
    struct hugo_type *hugoptr;
    struct hugo_type h;
    struct bingenetype Xgenerec; 
    struct bingenetype *Xgenerec_ptr; 


    fp = fopen (universe_fn,"r");
    errorcode = errno;
    if (!fp) { fprintf(stderr,"Can not open user specified  \"universe\" file - %s , errno=%d\n",universe_fn,errorcode); return -1; }

    for (i=0;i<numbingenes;i++) parah[i].status = 0;  // assume "guilty" in parallel hugo file
    s[0] = (char)0;
    while (fgets(s,20000,fp))
    {
        for (i=0;s[i];i++) { if (s[i] == '\n') s[i] = (char)0; if (s[i] == '\r') s[i] = (char)0; }
        h.hugo = strdup(s);
        hugoptr = bsearch(&h,parah,numbingenes,sizeof(struct hugo_type),cmp_hugo);
        if (hugoptr) hugoptr->status = 1; // "innocent"
        free(h.hugo);
    }
    fclose(fp);

    for (i=0 ; i<numbinpaths ; i++) // for each pathway
    {
       new_fix_gene_count = binpath[i].numgenes;
       o2g = binpath[i].offset2geneids;
       if (o2g<=0) continue;
       iptr = (int *)(spaceptr + o2g);
       for (j=0 ; j<binpath[i].numgenes ; j++)  // for each gene for this pathway
       {
           geneid = *(iptr+j);
           found = 0;
           // memset(&Xgenerec,0,sizeof(struct bingenetype)); not needed
           Xgenerec.geneid = geneid;
           Xgenerec_ptr = bsearch(&Xgenerec,&bingene[0],numbingenes,sizeof(struct bingenetype),cmp_bingene);
           if (Xgenerec_ptr)
           {
               strcpy(tmphugo, Xgenerec_ptr->hugo);
               h.hugo = &tmphugo[0];
               hugoptr = bsearch(&h,parah,numbingenes,sizeof(struct hugo_type),cmp_hugo);
               if (hugoptr)
               {
                   found = 1;
                   if (hugoptr->status == 0) // not in universe
                   {
//                fprintf(stderr,"%s removed \n",tmphugo); fflush(stderr);  
                       new_fix_gene_count--;
                   }
               }
           }
           if (found == 0) 
           {
               fprintf(stderr,"Error: Can not find %d\n",geneid); 
               exit(0);
           }
       }
       if (binpath[i].numgenes != new_fix_gene_count)
            binpath[i].numgenes  = new_fix_gene_count;
    }
    j = 0;
    for (i=0;i<numbingenes;i++)
    {
       if (parah[i].status == 1) j++;
    }
fprintf(stderr,"fixing new universe to new %d from old %d\n",j,*numg_ptr); fflush(stderr);
    *numg_ptr = j;
    return 0;
}



static int deal_with_custom_file(char custom_fn[],int numbingenes, int numbinpaths, int *numg_ptr, unsigned char *spaceptr, struct hugo_type parah[]) 
{
    char s[20000];
    int i,j;
    int errorcode;
    FILE *fp;


    fp = fopen(custom_fn,"r");
    errorcode = errno;
    if (!fp) { fprintf(stderr,"Can not open user specified  \"custom pathway\" file - %s , errno=%d\n",custom_fn,errorcode); return -1; }

    numcustom = 0;
    while (fgets(s,20000,fp))
    {
        numcustom++;
    }
    rewind(fp);
    if (numcustom == 0) return -1;
    customlist = (void *)malloc(sizeof(char *)*numcustom);
    if (!customlist)  { fprintf(stderr,"Can not malloc space for \"custom pathway\" file: %s  \n",custom_fn); return -1; }
    j = 0; 
    while (fgets(s,20000,fp))
    {
        for (i=0;s[i];i++) { if (s[i] == '\n') s[i] = (char)0; if (s[i] == '\r') s[i] = (char)0; }
        *(customlist + j) = strdup(s);
        j++;
    }
    fclose(fp);

#if 0
    NO numusedpaths= j;
    NO , just deal with it at the end
    if (customflag) 
    {
fprintf(stderr,"reserving space for custom ");
        binpath[numbinpaths].category = CAT_CUSTOM; // binpath has extra space 
        numbinpaths++;  // allow one custom pathway
    }
#endif

// fprintf(stderr,"loaded custom %d genesfor \"%s\" from %s\n",numcustom,custom_name,custom_fn);
    return 0;
}
#endif

void usage(void)
{
fprintf(stderr,"l2p : \"list to pathways\" program.\n");
fprintf(stderr,"Usage: cat listofHUGOgenes_one_per_line.txt | l2p [optional args]\n");
fprintf(stderr,"possible optional args are ...\n");
fprintf(stderr," -help\n");
fprintf(stderr," -precise\n");
fprintf(stderr," -noheader\n");
fprintf(stderr," -universe=Universefile_one_gene_per_line.txt\n");
fprintf(stderr," -categories=listofcatgories  (comma separated)\n");
fprintf(stderr,"    example: -categories=KEGG,REACTOME,BIOCYC,PANTH  (i.e. only use genes in those 4 categories\n");
fprintf(stderr,"    another -categories example: \"-categories=H,C6\"  (i.e. only use msigdb's Hallmark and C6 (cancer) category pathways\n");
fprintf(stderr,"    available categories are :\n");
fprintf(stderr,"    BIOCYC  - organism specific Pathway/ Genome Databases (PGDBs)  - https://biocyc.org/\n");
fprintf(stderr,"    GO  - initiative to unify representation of gene and gene product attributes -  http://geneontology.org\n");
fprintf(stderr,"    KEGG - databases dealing with genomes, biological pathways, - https://www.kegg.jp/\n");
fprintf(stderr,"    PANTH - databases for protein analysis through evolutionary relationships - http://www.pantherdb.org/\n");
fprintf(stderr,"    PID  - Pathway interaction database: legacy database from Carl Schaefer & buddies at NCI\n");
fprintf(stderr,"    REACTOME - curated database of biological pathways - https://reactome.org/\n");
fprintf(stderr,"    WikiPathways - community resource for biological pathways - https://www.wikipathways.org\n");
fprintf(stderr,"    C1 - MSigDB only, positional gene sets for each human chromosome and cytogenetic band.\n");
fprintf(stderr,"    C2 - MSigDB only, curated gene sets from online pathway databases, publications in PubMed, and experts.\n");
fprintf(stderr,"    C3 - MSigDB only, motif gene sets based on conserved cis-regulatory motifs from comparative analysis\n");
fprintf(stderr,"    C4 - MSigDB only, computational gene sets defined by mining large collections of cancer-oriented microarray data.\n");
fprintf(stderr,"    C5 - MSigDB only, gene sets  consist of genes annotated by the same GO terms.\n");
fprintf(stderr,"    C6 - MSigDB only, oncogenic gene sets defined directly from microarray data from cancer gene perturbations.\n");
fprintf(stderr,"    C7 - MSigDB only, immunologic gene sets  from microarray data from immunologic studies.\n");
fprintf(stderr,"    H - MSigDB only, hallmark gene sets: signatures from MSigDB gene sets to represent biological processes.\n");
fprintf(stderr,"Example run : printf \"TP53\\nPTEN\\nAPC\\nKRAS\\nNRAS\\n\" | ./l2p -categories=PID | sort -k2,2n -k1,1n -k3,3nr | head\n");
            fflush(NULL);
}

void int2bin(int n, char s[]) 
{
    int i;
    for (i=0;i<40;i++) s[0] = (char)0;
    // determine the number of bits needed ("sizeof" returns bytes)
    int nbits = sizeof(n) * 8;
    // forcing evaluation as an unsigned value prevents complications
    // with negative numbers at the left-most bit
    unsigned int u = *(unsigned int*)&n;
    unsigned int mask = 1 << (nbits-1); // fill in values right-to-left
    for (i = 0; i < nbits; i++, mask >>= 1)
    {
            s[i] = ((u & mask) != 0) + '0';
            s[i+1] =  (char)0;
    }
    return;
}

int bitCount(int n) 
{
    int cnt = 0;
    while (n) 
    {
        cnt += n % 2;
        n >>= 1;
    }
    return cnt;
}

static int parsecats(char *z)
{
    char ts[16][16];
    int bit;
    int j,k;
    int toks;

    for (j=0 ; *(z+j) ; j++)
    {
        if (*(z+j) == ',') *(z+j) = ' ';
    }
    memset(ts,0,sizeof(ts));
    toks = sscanf(z,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s ",
          ts[0], ts[1], ts[2], ts[3], ts[4], ts[5], ts[6], ts[7], ts[8], ts[9],
          ts[10], ts[11], ts[12], ts[13], ts[14], ts[15]);
    for (k=0;k<toks;k++)
    {
        bit=string_to_category_code(ts[k]);
        if (bit)
            catspat |= bit;
        else
        {
            fprintf(stderr,"ERROR: invalid category = %s\n",ts[k]);
            usage();
            exit(0);
        }
    }
    j = bitCount(catspat) ;
    if (j == 0)
    {
#ifdef L2P_USING_R
        return 0;
#else
        fprintf(stderr,"ERROR: no categories specified\n");
        usage();
        return -1;
#endif
    }
    return 0;
}

int l2p_init_C(int Rflag,int argc,char *argv[])
{
    char *z;
    int i;

    customflag = 0;
    universe_file[0] = custom_file[0] = 0;
    for (i=1 ; i<argc ; i++)
    {
        if ((strcmp(argv[i],"-help") == 0) || (strcmp(argv[i],"--help") == 0) || ((strcmp(argv[i],"help") == 0) ) )
        {
             usage();
             exit(1);
        }
        if (strncmp(argv[i],"-categories=",12) == 0)
        {
            z = argv[i], 
            z += 12;
            parsecats(z);
        }
        if (strcmp(argv[i],"-precise") == 0)
              precise_flag = 1; // print more digits out some user doesn't complain about "real pvals"
        if (strcmp(argv[i],"-noheader") == 0)
              no_header_flag = 1;
        if (strncmp(argv[i],"-universe=",10) == 0)
        {
            strcpy(universe_file,argv[i] + 10);
            user_universe_flag = 1;
fprintf(stderr,"note: using \"%s\" as universe file\n",universe_file);
        }
        if (strncmp(argv[i],"-customfile=",12) == 0)
        {
            strcpy(custom_file,argv[i] + 12);
            customflag++;
fprintf(stderr,"note: using \"%s\" as custom pathway gene listfile\n",custom_file);
        }
        if (strncmp(argv[i],"-customname=",12) == 0)
        {
            strcpy(custom_name,argv[i] + 12);
            customflag++;
fprintf(stderr,"note: using \"%s\" as custom pathway name\n",custom_name);
        }
/*
        else if (strcmp(argv[i],"enc") == 0)
        {
            fprintf(stderr,"info: encode mode\n");
            // encode_flag = 1;
        }
*/
    } 
    if (customflag == 1) strcpy(custom_name,"custom_pathway"); // user did not specify name, so give it one
    if (catspat == 0) category_set_all(&catspat);
    return 0;
}


int l2p_init_R()
{
    char s[100];

//   fprintf(stderr,"in l2p_init_R\n"); fflush(NULL);
    int2bin(catspat,s);
//fprintf(stderr,"rpf in l2p_init_R , in catspat=%d=0x%x %s\n",catspat,catspat,s);  fflush(NULL);
    universe_file[0] = 0;
    if (catspat == 0) category_set_all(&catspat);

    return 0;
}

char* mystrcat( char* dest, char* src )
{
     int kick = 0;
     while (*dest) dest++;
     while (1)
     {
         if (*src == (char)0) kick = 1;
         *dest++ = *src++;
         if (kick) break;
     }
     return --dest;
}


int init_bin_dat(void)
{
    FILE *fp;
    int system_errorcode;
    int i,j;
    long int li;
    size_t sz;


#if WEBASSEMBLY
    fprintf(stderr,"in init_bin_data, exedir=%s\n",exedir); 
#endif

    sprintf(fn_pathbin,"%s%s",exedir, "pathworks.bin");
    sprintf(fn_genesbin,"%s%s",exedir,"pathworksgenes.bin");
    sprintf(fn_spacebin,"%s%s",exedir,"pathworksspace.bin");

    if (numbinpaths == 0) 
    {
        fp = fopen (fn_pathbin,"r");
        system_errorcode = errno;
        if (!fp) 
        { 
            fprintf(stderr,"Can not open \"path binary data\" - %s - errno=%d\n",fn_pathbin,system_errorcode);  fflush(NULL);
            goto LOAD_ERROR;
        }
        fseek(fp, 0L, SEEK_END);
        li = ftell(fp);
        // NO numbinpaths = li / sizeof(struct binpathouttype);
        numbinpaths = li / (size_t)40; // hard coded to 40 , the record size is 40 bytes (which may not equal sizeof binpath_type)
        rewind(fp);
        for (j=i=0 ; i<numbinpaths ; i++)
        {
            sz = fread(&binpath[i].bsid,sizeof(int),1,fp);
            if (sz != 1) {fprintf(stderr,"ERROR reading %dth record of %s sz=%zu recsize=%zu\n",j,fn_pathbin,sz,sizeof(struct binpathouttype)); fflush(NULL); exit(0); }
            sz=fread(&binpath[i].category,sizeof(int),1,fp);
            if (sz != 1) {fprintf(stderr,"ERROR reading %dth record of %s sz=%zu recsize=%zu\n",j,fn_pathbin,sz,sizeof(struct binpathouttype)); fflush(NULL); exit(0); }
            sz=fread(&binpath[i].accession,sizeof(int),1,fp);
            if (sz != 1) {fprintf(stderr,"ERROR reading %dth record of %s sz=%zu recsize=%zu\n",j,fn_pathbin,sz,sizeof(struct binpathouttype)); fflush(NULL); exit(0); }
            sz=fread(&binpath[i].name,sizeof(int),1,fp);
            if (sz != 1) {fprintf(stderr,"ERROR reading %dth record of %s sz=%zu recsize=%zu\n",j,fn_pathbin,sz,sizeof(struct binpathouttype)); fflush(NULL); exit(0); }
            sz=fread(&binpath[i].type,sizeof(int),1,fp);
            if (sz != 1) {fprintf(stderr,"ERROR reading %dth record of %s sz=%zu recsize=%zu\n",j,fn_pathbin,sz,sizeof(struct binpathouttype)); fflush(NULL); exit(0); }
            sz=fread(&binpath[i].scope,sizeof(int),1,fp);
            if (sz != 1) {fprintf(stderr,"ERROR reading %dth record of %s sz=%zu recsize=%zu\n",j,fn_pathbin,sz,sizeof(struct binpathouttype)); fflush(NULL); exit(0); }
            sz=fread(&binpath[i].taxid,sizeof(int),1,fp);
            if (sz != 1) {fprintf(stderr,"ERROR reading %dth record of %s sz=%zu recsize=%zu\n",j,fn_pathbin,sz,sizeof(struct binpathouttype)); fflush(NULL); exit(0); }
            sz=fread(&binpath[i].desc,sizeof(int),1,fp);
            if (sz != 1) {fprintf(stderr,"ERROR reading %dth record of %s sz=%zu recsize=%zu\n",j,fn_pathbin,sz,sizeof(struct binpathouttype)); fflush(NULL); exit(0); }
            sz=fread(&binpath[i].numgenes,sizeof(int),1,fp);
            if (sz != 1) {fprintf(stderr,"ERROR reading %dth record of %s sz=%zu recsize=%zu\n",j,fn_pathbin,sz,sizeof(struct binpathouttype)); fflush(NULL); exit(0); }
            sz=fread(&binpath[i].offset2geneids,sizeof(int),1,fp);
            if (sz != 1) {fprintf(stderr,"ERROR reading %dth record of %s sz=%zu recsize=%zu\n",j,fn_pathbin,sz,sizeof(struct binpathouttype)); fflush(NULL); exit(0); }
            if (catspat & binpath[i].category)
               j++;
/* debug else { char ss1[100]; char ss2[100]; int2bin(catspat,ss1); int2bin(binpath[i].category,ss2); catspat,ss1,i,binpath[i].category,binpath[i].category,ss2); } */
        }
        fclose(fp);
        fp = (FILE *)0;
    }

    if (numbingenes == 0)
    {
        fp = fopen (fn_genesbin,"r");
        system_errorcode = errno;
        if (!fp) { fprintf(stderr,"Can not open \"genes data\". filename: %s, errno=%d\n",fn_genesbin,system_errorcode); exit(0); }
        fseek(fp, 0L, SEEK_END);
        li = ftell(fp);
        numbingenes = (int)(li / sizeof(struct bingenetype));
    // fprintf(stderr,"rpf in init_bin_dat  numbingenes=%d \n",numbingenes); fflush(stderr);
        rewind(fp);
        numg = 0;
        for (i=0 ; ((i<numbingenes)&&(i<MAXGENE)) ; i++)
        {
            sz = fread(&bingene[i],sizeof(struct bingenetype),1,fp);
            system_errorcode = errno;
            if (sz != 1) {fprintf(stderr,"ERROR reading genes at %dth record of \"%s\". errno=%d\n",i,fn_genesbin,system_errorcode); fflush(NULL); exit(0); }
            if (catspat == 0) numg++;
            else if (catspat & bingene[i].categories) numg++;
        }
        fclose(fp);
        fp = (FILE *)0;
    }

// -- for "spill over" , path and genes have some fields which are pointers (actually offsets!) to variable sized data in space
// these are accessed by integer offset (i.e. pointers) to null terminated strings or known sized array of ints
    if (!ucz) 
    {
        fp = fopen (fn_spacebin,"r");
        system_errorcode = errno;
        if (!fp) { fprintf(stderr,"Can not open \"path space data\" - %s - errno=%d\n",fn_spacebin,system_errorcode); exit(0); }
        fseek(fp, 0L, SEEK_END);
        spacesize = ftell(fp);
        rewind(fp);
        ucz = malloc((size_t)spacesize); if (!ucz) { fprintf(stderr,"ERROR: can't malloc in space for \"spill\" data\n"); return 0; }
        sz = fread(ucz,spacesize,1,fp);
        if (sz != 1) {fprintf(stderr,"ERROR reading \"spill space\" file %s\n",fn_spacebin); fflush(NULL); exit(0); }
        fclose(fp);
        fp = (FILE *)0;
    }

    return 0;

LOAD_ERROR:
    if (ucz) { free(ucz); ucz = (unsigned char *)0; }
    return -1;
}


#if WEBASSEMBLY
#include <emscripten/emscripten.h>

FILE *fpreport;

void output_anno(void ) 
{
    int len;
    char *script;
    size_t tsize;
    int status;

fprintf(stderr,"in output_anno , fpreport = %p",fpreport); fflush(stderr); 
    if (!fpreport) return;

    tsize = ftell(fpreport);
    fprintf(stderr,"in output_anno , size = %zu",tsize); fflush(stderr); 
    if (tsize)
    {
        script = malloc(tsize+100); // we have 100 bytes to package pre and post stuff
        if (script)
        {
            *(script) = (char)0;
            strcpy(script,"var mydb=document.getElementById('anno');mydb.innerHTML=\"");
            len = strlen(script);
            rewind(fpreport);
            status = fread(script+len,tsize,1,fpreport); // after the "primer" 
            sprintf(script+tsize+len,"</tbody></table><br>\";"); // append "sealant" to make the final product
// fprintf(stderr,"in output_anno , script = %s",script); fflush(stderr); 
fprintf(stderr,"before script to anno"); fflush(stderr); 
             emscripten_run_script(script);
fprintf(stderr,"after script to anno"); fflush(stderr); 
            if (script) { free(script); script = (char *)0; }
        }
    }
    return;
}


void clear_anno(void) 
{
    char script[512];

    strcpy(script,"var mydb=document.getElementById('anno');mydb.innerHTML=\"\";");
    emscripten_run_script(script);
    return;
}


void init_display_results()    
{
    fpreport = tmpfile();
    if (fpreport)
    {
        fprintf(fpreport,"<table border='1' style='border-collapse:collapse'>");
        fprintf(fpreport,"<thead><tr><th>pval</th><th>fdr</th><th>ratio</th><th>pathwayhitcount</th><th>numgenesinpw</th><th>inputnumofgenes</th><th>genesinpathwaysuniverse</th><th>pathwayaccessionid</th><th>category</th><th>pathwayname</th><th>pathwaytype</th><th>genes</th></tr></thead>"); 
        fprintf(fpreport,"<tbody>");
    }
    return;
}

void display_results()    
{
fprintf(stderr,"in display_results fpreport=%p\n",fpreport); fflush(stderr);
    if (!fpreport) return;

fprintf(stderr,"in display_results before output_anno fpreport=%p\n",fpreport); fflush(stderr); 
    output_anno();
fprintf(stderr,"in display_results after output_anno\n"); fflush(stderr); 
    fclose(fpreport);
    fpreport = (FILE *)0;
    return;
}

void add_to_table(int pwindex,  double pval, double fdr, double ad, 
		int hitcntarg, int ingenecnt, int numgenes, int numg, char accession[], 
		char catz[], char name[], char type[], struct hit_type *hitzrec)
{
  // communicate the pathways results to javascript ...
    struct bingenetype *bingptr; 
    char *genes = (char *)0;
    char *z = (char *)0;
    int j = 0;
    char blank[10];
    int len = 0;
    int local_malloced_flag = 0;

    if (!fpreport)
    {
        fprintf(stderr,"ERROR in add_to_table, fpreport not open.\n"); fflush(stderr); 
        return;
    }

    blank[0] = ' ';
    blank[1] = (char)0;

    if (hitcntarg)
    {
	genes = malloc((size_t)(28*(hitzrec->hitcnt)));  // maxgenenamelen=26 ARHGAP27P1-BPTFP1-KPNA2P3
        if (!genes) { fprintf(stderr,"ERROR no mem. in add_to_table()\n"); return; }
        local_malloced_flag = 0;
        memset(genes,0,(size_t)(28*(hitzrec->hitcnt)));
	z = genes;
        for (j=0 ; j<(hitzrec->hitcnt) ; j++)
        {
            bingptr =  &bingene[*(hitzrec->hitsindexes + j)];
	    len = strlen(bingptr->hugo);
	    strcat(z,bingptr->hugo);
	    z+=len;
	    strcat(z," ");
	    z++;
        }
    }
    else 
    {
	local_malloced_flag = 0;
        genes = &blank[0];
    }
// fprintf(stderr,"genes=%s\n",genes);  fflush(stderr);
    fprintf(fpreport,"<tr><td>%20.18f</td><td>%20.18f</td><td>%20.18f</td><td>%d</td><td>%d</td><td>%d</td><td>%d</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>",
         pval , fdr , ad, hitcntarg , ingenecnt, numgenes , numg , accession , catz , name , type , genes); 
    if (local_malloced_flag) 
    {
        if (genes) { free(genes); }
        genes = (void *)0;
    }
    return;
}
#endif


void dump_custom_hits(void)
{
    int i,j;

    for (i=0 ; i<numuserinput ; i++)
    {
         for (j=0 ; j<numcustom ; j++)
         {
             if (strcmp(*(userinput+i),*(customlist+j))==0) 
             {
                 printf("%s ",*(userinput+i));
             }
         }
    }
    return;
}

#ifdef L2P_USING_R
SEXP l2p_core( int Rflag, int numingenes,char *genelist[], SEXP ulist, char **clist,int msigflagarg)
#else
static int l2p_core( int Rflag, int numingenes,char *genelist[], int msigflagarg)
#endif
{
    char tmps_cat[40]; // temp string for "category" 
    struct hugo_type *hugoptr = (void *)0;
    struct hugo_type h;
    struct bingenetype *bingenerec_ptr = (void *)0; 
    struct binpathouttype *binpathptr = (void *)0;
    int hitcnt = 0;
    int i = 0;
    int j;
    int idx = 0;
    int ingenecnt = 0;
    struct hit_type *hitz;
    unsigned int curcount;
    // int numhugos;


#ifdef L2P_USING_R
   unsigned int *usintptr = (void *)0;
   char *p;
   char *p2;
   int k;
   SEXP pval; // 1 
   SEXP fdr; // 2
   SEXP ratio;                      // 3 if positive, genes are OVER REPRESENTED, if negative genes are UNDER REPRESENTED
   SEXP pathwayhitcount;            // 4 number of genes hit in pathway
   SEXP numberofgenesinpathway;     // 5 number of genes in the pathway
   SEXP inputnumberofgenes;         // 6 total count of user genes (user input)
   SEXP genesinpathwaysuniverse;    // 7 total number of unique genes in all pathways
   SEXP pathwayaccessionidentifier; // 8 canonical accession ( if availible, otherwise assigned by us )
   SEXP category;                   // 9 KEGG,REACTOME,GO,PANT(=PANTHER),PID=(pathway interaciton database)
   SEXP pathwayname;                // 10 Name of pathway
   SEXP genesinpathway;             // 11 genes_space_separated   HUGO genes from user that hit the pathway
   int maxflds = 11;
   SEXP Rret;
   SEXP cls; // R class 
   SEXP nam; // R name 
   SEXP rownam; // row names
   int protect_cnt = 0;

//    fprintf(stderr,"rpf inl2p_core numingens = %d \n",numingenes); 
#else

#if WEBASSEMBLY
fprintf(stderr,"in l2pcore() wasm %p %d\n",genelist , numingenes); fflush(stderr);
#else
// regular c
    char s[20000];
#endif
#endif

    // numg = 28992 now set at runtime
#if 0
    if (encode_flag)
    {
// not used
        // numg = 26568;
        sprintf(fn_pathbin,"%s%s",exedir,"encpath.bin");
        sprintf(fn_genesbin,"%s%s",exedir,"encgenes.bin");
        sprintf(fn_spacebin,"%s%s",exedir,"encspace.bin");
    }
    else if (panther_only_flag)
    {
// not used
        // numg = 2238;
        sprintf(fn_pathbin, "%s%s",exedir,"pantherworks.bin");
        sprintf(fn_genesbin,"%s%s",exedir,"pantherworksgenes.bin");
        sprintf(fn_spacebin,"%s%s",exedir,"pantherworksspace.bin");
    }
    else if (msig_flag)
    {
// numg = 25785;
        sprintf(fn_pathbin, "%s%s",exedir,"msigpath.bin");
        sprintf(fn_genesbin,"%s%s",exedir,"msiggenes.bin");
        sprintf(fn_spacebin,"%s%s",exedir,"msigspace.bin");
    }
    else
#endif

    if (init_bin_dat() < 0) // may load if 1st time 
    {
#ifdef L2P_USING_R
        return (SEXP)0;
#else
        return 0;
#endif
    }

             // -- need hugo name access, so set up a parallel array
    parallel_hugos = setup_hugo_parallel_to_genebin( numbingenes);
    if (!parallel_hugos) return 0;
    // not used numhugos=numbingenes;
    if (customflag) // add one extra for custom
    {
         hitz = malloc(sizeof(struct hit_type)*(numbinpaths+1)),
         memset(hitz,0,sizeof(struct hit_type)*(numbinpaths+1));
    }
    else 
    {
         hitz = malloc(sizeof(struct hit_type)*(numbinpaths));
         memset(hitz,0,sizeof(struct hit_type)*(numbinpaths));
    }

    if (user_universe_flag)
    {
#ifdef L2P_USING_R
        if (R_deal_with_universe_list(ulist,numbingenes,numbinpaths,&numg,ucz) != 0)
        {
// fprintf(stderr,"rpf after R_deal_with_universe_list(), return badness\n");
            return 0;
        }
#else
        if (deal_with_universe_file(universe_file,numbingenes,numbinpaths,&numg,ucz,parallel_hugos) != 0)
            return 0;
#endif
    }

    if (customflag)
    {
#ifdef L2P_USING_R
        customlist = clist;
#else
        if (deal_with_custom_file(custom_file,numbingenes,numbinpaths,&numg,ucz,parallel_hugos) != 0)
            return 0;
#endif
    }

    ingenecnt = 0;


#ifdef L2P_USING_R
    for (k=0;k<numingenes;k++)
#else

#if WEBASSEMBLY
    for (int k=0;k<numingenes;k++)
#else
    while ( fgets(s, sizeof(s), stdin) ) // gets() function is deprecated
#endif

#endif
    {
#ifdef L2P_USING_R
        h.hugo = strdup(genelist[k]);
        if (customflag) adduserinputgene(h.hugo);
#else
#if WEBASSEMBLY
        h.hugo = strdup(genelist[k]);
//  fprintf(stderr,"in l2pcore() wasm after strdup %s, k=%d\n",h.hugo,k); fflush(stderr);
#else
        for (i=0;s[i];i++) { if (s[i] == '\n') s[i] = (char)0; if (s[i] == '\r') s[i] = (char)0; }
        h.hugo = strdup(s);
        if (customflag) adduserinputgene(h.hugo);
// fprintf(stderr,"in l2pcore() C after strdup %s\n",h.hugo); fflush(stderr);
#endif
#endif
        hugoptr = bsearch(&h,parallel_hugos,numbingenes,sizeof(struct hugo_type),cmp_hugo);
// fprintf(stderr,"in l2pcore() hugoptr=%p\n",hugoptr); fflush(stderr);
        if (hugoptr)
        {
            bingenerec_ptr = hugoptr->generec_ptr;
#if 0
fprintf(stderr,"in l2pcore() got h.hugo is %s, hugoptr=%p, hugoptr->generec_ptr=%p \n",h.hugo,hugoptr,hugoptr->generec_ptr); fflush(stderr);
fprintf(stderr,"here \n"); fflush(stderr);
fprintf(stderr,"in l2pcore() got h.hugo is %s, hugoptr=%p, hugoptr->generec_ptr=%p pathcount=%d\n",h.hugo,hugoptr,hugoptr->generec_ptr,bingenerec_ptr->pathcount); fflush(stderr);
#endif
            if (!bingenerec_ptr) { fprintf(stderr,"ERROR: null generecptr\n"); fflush(stderr); exit(0); }
            if ((bingenerec_ptr)->pathcount)
            {
// fprintf(stderr,"in l2pcore() in generec_ptr.pathcount =%d bingenerec_ptr=%p hugo=%s\n",bingenerec_ptr->pathcount,bingenerec_ptr,hugoptr->hugo); fflush(stderr);
                 ingenecnt++;
                 if (bingenerec_ptr->pathplace == -1) { fprintf(stderr,"ERROR: should not get pathplace of -1 with a pathcount\n");  exit(0); }
                 if (bingenerec_ptr->pathplace == 0) { fprintf(stderr,"ERROR: should not get pathplace of 0 with a pathcount\n");  exit(0); }
                 for (i=0; i < bingenerec_ptr->pathcount ; i++) // go through the paths for this gene, add hit to paths
                 {
                     idx = *(int *)(ucz + bingenerec_ptr->pathplace + (i*4)); // get INDEX of record in binpath[]
                     binpathptr = &binpath[idx];
		char *tmpsacc = (char *)(ucz+((binpathptr)->accession ));
// fprintf(stderr,"in l2pcore() wasm in genrec for i=%d binpathptr=%p hitcnt=%u i=%d idx=%d of %d\n",i,binpathptr,(hitz+i)->hitcnt,i,idx,numingenes); fflush(stderr);
                     curcount = (hitz+idx)->hitcnt;
                     if ( curcount == (unsigned int)0)
                     {    // intialize this 
//  fprintf(stderr,"in l2pcore() wasm hits=void got index for gene %u, numgenes=%d\n", (unsigned int)(bingenerec_ptr - &bingene[0]),binpathptr->numgenes); fflush(stderr);
                         (hitz+idx)->hitcnt = 1;
                         (hitz+idx)->maxhits = (unsigned int)(binpathptr->numgenes+2);
                         (hitz+idx)->hitsindexes = (unsigned int *)malloc((size_t)(binpathptr->numgenes+2) *4);
                         *((hitz+idx)->hitsindexes) = (unsigned int)(bingenerec_ptr - &bingene[0] ); // an index
//  fprintf(stderr,"in l2pcore() wasm end histwasvoid, now put %u in 1st pos\n",(unsigned int)(bingenerec_ptr - &bingene[0] )); fflush(stderr);
                     }
                     else
                     {
//  fprintf(stderr," in l2pcore() wasm else start, binpathptr=%p hits=%u\n",binpathptr,*(unsigned int *)(hitz+idx));
			 if (curcount >= (hitz+idx)->maxhits)
			 {
  fprintf(stderr," error %d > %d %s\n",curcount , (hitz+idx)->maxhits,tmpsacc);
  exit(0);
			 }
                         *(((hitz+idx)->hitsindexes)+curcount) = (unsigned int)(bingenerec_ptr - &bingene[0] ); // an index
			 (hitz+idx)->hitcnt = curcount + 1;
			if (strcmp("ko00780",tmpsacc) == 0)
			{
			}
                     }
                     curcount = (hitz+idx)->hitcnt;
//fprintf(stderr," IIIII in l2pcore() wasm curcount=%u for pw:%s added %s\n",curcount,tmpsacc,h.hugo); fflush(stderr);
// fprintf(stderr,"in l2pcore() wasm end for bingenerec_ptr->pathcount=%d\n",bingenerec_ptr->pathcount); fflush(stderr);
                }
            }
// fprintf(stderr,"in l2pcore() wasm after genrec\n"); fflush(stderr);
        }
	else
	{
		// bad gene input
// fprintf(stderr,"debug in l2pcore() after hugoptr=%p. SHOULD NOT BE NULL., searched for %s\n",hugoptr,h.hugo); fflush(stderr);
	}
        if (h.hugo) { free(h.hugo); h.hugo = (char *)0; }
    }
// fprintf(stderr,"in l2pcore() BEFORE do_pvals_and_bh()\n"); fflush(stderr);
    do_pvals_and_bh(numg,ingenecnt,hitz);
// fprintf(stderr,"in l2pcore() AFTER  do_pvals_and_bh()\n"); fflush(stderr);

#ifdef L2P_USING_R
    PROTECT(Rret = Rf_allocVector(VECSXP, 11)); // a list with 11 elements
    protect_cnt++;
    for (i=0 ; i<maxflds ; i++) // maxflds = 11 for now
    {
        PROTECT(pval=Rf_allocVector(REALSXP, numusedpaths ));
        PROTECT(fdr=Rf_allocVector(REALSXP, numusedpaths));
        PROTECT(ratio=Rf_allocVector(REALSXP, numusedpaths));
        PROTECT(pathwayhitcount=Rf_allocVector(INTSXP, numusedpaths));
        PROTECT(numberofgenesinpathway=Rf_allocVector(INTSXP, numusedpaths));
        PROTECT(inputnumberofgenes=Rf_allocVector(INTSXP, numusedpaths));
        PROTECT(genesinpathwaysuniverse=Rf_allocVector(INTSXP, numusedpaths));
        PROTECT(pathwayaccessionidentifier=Rf_allocVector(STRSXP, numusedpaths));
        PROTECT(category=Rf_allocVector(STRSXP, numusedpaths));   // is natively an int, but convert to string
        PROTECT(pathwayname=Rf_allocVector(STRSXP, numusedpaths));
        PROTECT(genesinpathway=Rf_allocVector(STRSXP, numusedpaths));
        protect_cnt+=11;
    }
#else
    if (no_header_flag == 0)
        printf("pval\tfdr\tratio\tpathwayhitcount\tnumgenesinpw\tpathway\tinputnumofgenes\tgenesinpathwaysuniverse\tpathwayaccessionid\tcategory\tpathwayname\tpathwaytype\tgenes\n");
#endif

#if WEBASSEMBLY
    qsort(usedpaths,numusedpaths,sizeof(struct used_path_type ),cmp_binpath);
//    for (i=0 ; i<200 ; i++) fprintf(stderr,"fdr=%f pval=%f ad=%f %s\n",usedpaths[i].fdr,usedpaths[i].pval,usedpaths[i].ad,(char *)(ucz+(binpathptr)->accession));
    for (i=0 ; i<200 ; i++)  /* i<numusedpaths; */
    {
        binpathptr = &binpath[usedpaths[i].bpindex];
        tmps_cat[0] = (char)0;
        category_code_to_string( (binpathptr)->category , tmps_cat);
        hitcnt = (hitz+usedpaths[i].bpindex)->hitcnt;
        add_to_table( i,usedpaths[i].pval, usedpaths[i].fdr, usedpaths[i].ad, hitcnt, (binpathptr)->numgenes, ingenecnt, numg, 
                (char *)(ucz+(binpathptr)->accession), tmps_cat, (char *)(ucz+(binpathptr)->name), type2string((binpathptr)->type), hitz+usedpaths[i].bpindex);
    }
fprintf(stderr,"in wasm after add_to_table loop, numingenes=%d, numusedpaths=%d\n",numingenes,numusedpaths); fflush(stderr); 
fprintf(stderr,"wasm all done? (except for freeing stuff.) \n"); fflush(stderr); 

      // be sure to free and rescue hits field in binpath ,next time we use it.
#else
    for (i=0 ; i<numusedpaths; i++)
    {
	if (usedpaths[i].bpindex == -1) strcpy(tmps_cat,"custom"); 
	else
	{
           binpathptr = &binpath[usedpaths[i].bpindex];
           tmps_cat[0] = (char)0;
           category_code_to_string( (binpathptr)->category , tmps_cat);
           hitcnt = (hitz+usedpaths[i].bpindex)->hitcnt;
	}

#ifdef L2P_USING_R
        REAL(pval)[i] = usedpaths[i].pval;
        REAL(fdr)[i] = usedpaths[i].fdr;
        REAL(ratio)[i] = usedpaths[i].ad;
        INTEGER(pathwayhitcount)[i] = hitcnt;
        INTEGER(numberofgenesinpathway)[i] = (binpathptr)->numgenes;
        INTEGER(inputnumberofgenes)[i] = ingenecnt;
        INTEGER(genesinpathwaysuniverse)[i] = numg;

	// xxx rpf
	if (usedpaths[i].moreinfo == 1) 
        {
            SET_STRING_ELT(pathwayaccessionidentifier, i, mkChar(custom_name));
        }
        else SET_STRING_ELT(pathwayaccessionidentifier, i, mkChar((char *)(ucz+((binpathptr)->accession ) ) ) ); 
        SET_STRING_ELT(category, i, mkChar(tmps_cat));
	if (usedpaths[i].moreinfo == 1) 
        {
            SET_STRING_ELT(pathwayname, i, mkChar(custom_name) );
        }
        else SET_STRING_ELT(pathwayname, i, mkChar( (char *)(ucz+((binpathptr)->name ) ) ) );
        SET_STRING_ELT(genesinpathway, i, mkChar( type2string((binpathptr)->type)) );

        p2 =  malloc((hitcnt+2) * 34);  // plus some extra space
        memset(p2,0,(hitcnt+2) * 34);
        if ((hitz+usedpaths[i].bpindex)->hitcnt)
        {
            int ii,jj;
            if ((usedpaths[i].moreinfo) == 1)
            {
                for (ii=0 ; ii<numuserinput ; ii++)
                {
                     for (jj=0 ; jj<numcustom ; jj++)
                     {
                         if (strcmp(*(userinput+ii),*(customlist+jj))==0) 
                         {
                             strcat(p2,*(userinput+ii));
                             strcat(p2," ");
                         }
                     }
                }
            }
            else
            {
                for (jj=0;jj<hitcnt;jj++)
                {
                    bingenerec_ptr = &bingene[*((hitz+usedpaths[i].bpindex)->hitsindexes+jj)];
                    if (bingenerec_ptr)
                    {
                        strcat(p2,bingenerec_ptr->hugo);
                        strcat(p2," ");
                    }
                }
            }
        }
        SET_STRING_ELT(genesinpathway, i, mkChar( p2 ) );
        if (p2) { free(p2); p2 = (char *)0; }
#else
        if (precise_flag == 1)
        {
                printf("%20.18f\t%20.18f\t%11.9f\t%d\t%d\t%d\t%d\t%s\t%s\t%s\t%s\t",
                    usedpaths[i].pval, usedpaths[i].fdr, usedpaths[i].ad,
                             hitcnt, (binpathptr)->numgenes, ingenecnt, numg,
                             (char *)(ucz+(binpathptr)->accession), tmps_cat,
                             (ucz+((binpathptr)->name)), type2string((binpathptr)->type));
        }
        else
        {
		// zzz 
                printf("%11.9f\t%11.9f\t%11.9f\t%d\t%d\t%d\t%d\t%s\t%s\t%s\t%s\t",
                    usedpaths[i].pval, usedpaths[i].fdr, usedpaths[i].ad,
                    hitcnt, (binpathptr)->numgenes, ingenecnt, numg,
                    (char *)(ucz+(binpathptr)->accession), tmps_cat,
                    (ucz+((binpathptr)->name)), type2string((binpathptr)->type));
        }
        if ((hitz+usedpaths[i].bpindex)->hitcnt)
        {
            if ((usedpaths[i].moreinfo) == 1)
            {
                dump_custom_hits();
            }
            else
            {
                for (j=0;j<hitcnt;j++)
                {
                    bingenerec_ptr =  &bingene[*((hitz+usedpaths[i].bpindex)->hitsindexes+j)];
                    printf("%s ",bingenerec_ptr->hugo);
                }
            }
        }

        printf("\n");
#endif
    }
#endif

#ifdef L2P_USING_R
   SET_VECTOR_ELT( Rret,0, pval);
   SET_VECTOR_ELT( Rret,1, fdr);
   SET_VECTOR_ELT( Rret,2, ratio);
   SET_VECTOR_ELT( Rret,3, pathwayhitcount);
   SET_VECTOR_ELT( Rret,4, numberofgenesinpathway);
   SET_VECTOR_ELT( Rret,5, inputnumberofgenes);
   SET_VECTOR_ELT( Rret,6, genesinpathwaysuniverse);
   SET_VECTOR_ELT( Rret,7, pathwayaccessionidentifier);
   SET_VECTOR_ELT( Rret,8, category);
   SET_VECTOR_ELT( Rret,9, pathwayname);
   SET_VECTOR_ELT( Rret,10, genesinpathway);

   PROTECT(cls = allocVector(STRSXP, 1)); // class attribute
   protect_cnt++;

   SET_STRING_ELT(cls, 0, mkChar("data.frame"));
   classgets(Rret, cls);

   PROTECT(nam = allocVector(STRSXP, 11)); // names attribute (column names)
   protect_cnt++;

   SET_STRING_ELT( nam ,                      0, mkChar("pval"));
   SET_STRING_ELT( nam,                        1, mkChar("fdr"));
   SET_STRING_ELT( nam,                      2, mkChar("ratio"));
   SET_STRING_ELT( nam,            3, mkChar("pathwayhitcount"));
   SET_STRING_ELT( nam,     4, mkChar("numberofgenesinpathway"));
   SET_STRING_ELT( nam,         5, mkChar("inputnumberofgenes"));
   SET_STRING_ELT( nam,    6, mkChar("genesinpathwaysuniverse"));
   SET_STRING_ELT( nam, 7, mkChar("pathwayaccessionidentifier"));
   SET_STRING_ELT( nam,                   8, mkChar("category"));
   SET_STRING_ELT( nam,                9, mkChar("pathwayname"));
   SET_STRING_ELT( nam,            10, mkChar("genesinpathway"));
   namesgets(Rret, nam);

   PROTECT(rownam = allocVector(STRSXP, numusedpaths )); // row.names attribute
   protect_cnt++;
   for (i=0 ; i<numusedpaths ; i++)
   {
       if (usedpaths[i].moreinfo == 1) 
       {
           SET_STRING_ELT(rownam, i, mkChar(custom_name) );
       }
       else
       {
           binpathptr = &binpath[usedpaths[i].bpindex];
           SET_STRING_ELT(rownam, i, mkChar( (char *)(ucz+((binpathptr)->accession ) ) ) );
       }
   }
   setAttrib(Rret, R_RowNamesSymbol, rownam);

// CORE_END:
   UNPROTECT(protect_cnt);
   if (genelist) 
   { 
       for (i=0 ; i<numingenes ; i++) { if (genelist[i]) {free(genelist[i]); } }
       free(genelist); genelist = (void *)0; 
   }
   if (parallel_hugos) free(parallel_hugos);
   parallel_hugos = (void *)0;

   if (ucz) { free(ucz); ucz = (void *)0; }
// fprintf(stderr,"in l2p_core() return Rret = %p\n",Rret); fflush(stdout);
   return Rret;
#else
   if (genelist) 
   { 
       for (i=0 ; i<numingenes ; i++) { if (genelist[i]) {free(genelist[i]); } }
       free(genelist); genelist = (void *)0; 
   }

   if (parallel_hugos) free(parallel_hugos);
   parallel_hugos = (void *)0;
   if (hitz) free(hitz);
   hitz = (void *)0;
   return 0;
#endif

// CORE_ERROR:
   if (genelist) 
   { 
       for (i=0 ; i<numingenes ; i++) { if (genelist[i]) {free(genelist[i]); } }
       free(genelist); genelist = (void *)0; 
   }
   if (parallel_hugos) free(parallel_hugos);
   parallel_hugos = (void *)0;
   if (hitz) free(hitz);
   hitz = (void *)0;
   return 0;
}


#ifdef L2P_USING_R

SEXP l2p(SEXP lst, SEXP fpath)
{
   char path[PATH_MAX];
   int lastslash;
   int i;
   int len;
   char **z;

// fprintf(stderr,"in  l2p() 0 \n"); fflush(stderr);
   user_universe_flag = 0;
   catspat=0;
   len = length(lst);
   strncpy(path,CHAR(STRING_ELT(fpath, 0)),PATH_MAX-2);
   z = (char **)malloc(sizeof(char *)*len);
   if (!z)
   {
        return (SEXP) -1;
   }
   for (i = 0; i < len; i++)
   {
       *(z+i) = strdup(CHAR(STRING_ELT(lst, i)));
   }
  lastslash = -1;
  for (i=0;path[i];i++)
  {
      if (path[i] == '/') lastslash = i;
  }
  if (lastslash > 0) path[lastslash] = (char)0;
  strcpy(exedir,path);
  strcat(exedir,"/");

  l2p_init_R();
  return l2p_core(1,len, z, (void *)0,(void *)0,0);
}

SEXP l2pgetlongdesc(SEXP accarg, SEXP fpath)
{
    char path[PATH_MAX];
    char acc[PATH_MAX];
    int i;	  
    struct binpathouttype *binpathptr;
    int lastslash;
    char *z;
 
    strncpy(acc,CHAR(STRING_ELT(accarg, 0)),PATH_MAX-2);
    strncpy(path,CHAR(STRING_ELT(fpath, 0)),PATH_MAX-2);
    lastslash = -1;
    for (i=0;path[i];i++)
    {
        if (path[i] == '/') lastslash = i;
    }
    if (lastslash > 0) path[lastslash] = (char)0;
    strcpy(exedir,path);
    strcat(exedir,"/");
    if (init_bin_dat() < 0) // may load if 1st time 
    {
        return (SEXP)0;
    }
    for (i=0 ; i<numbinpaths ; i++)
    {
        binpathptr = &binpath[i];
        z = (char *)(ucz+((binpathptr)->desc ) );
// fprintf(stderr,"l2pgetlongdesc %s %s\n",acc,z); fflush(NULL);
	if (z)
	{
            if (strcmp(acc,z) == 0)
               break;
	}
	else z = (char *)0;
    }
    SEXP ret = PROTECT(allocVector(STRSXP, 1));
    if (z)
        SET_STRING_ELT(ret, 0, mkChar(z));
    else
        SET_STRING_ELT(ret, 0, mkChar(""));
    UNPROTECT(1);
    return ret;
}

SEXP l2pgetgenes4acc(SEXP accarg, SEXP fpath)
{
    char path[PATH_MAX];
    char acc[PATH_MAX];
    char tmphugo[1024];
    struct hugo_type *hugoptr;
    struct hugo_type h;
    int *iptr;
    int i,j;	  
    int o2g;
    struct binpathouttype *binpathptr;
    char *z;
    char *z2;
    int geneid;
    struct bingenetype Xgenerec; 
    struct bingenetype *Xgenerec_ptr; 
    int lastslash;
 
    strncpy(acc,CHAR(STRING_ELT(accarg, 0)),PATH_MAX-2);
    strncpy(path,CHAR(STRING_ELT(fpath, 0)),PATH_MAX-2);
    lastslash = -1;
    for (i=0;path[i];i++)
    {
        if (path[i] == '/') lastslash = i;
    }
    if (lastslash > 0) path[lastslash] = (char)0;
    strcpy(exedir,path);
    strcat(exedir,"/");
    if (init_bin_dat() < 0) // may load if 1st time 
    {
        return (SEXP)0;
    }
    z2 = (char *)0;
    for (i=0;i<numbinpaths   ;i++)
    {
        binpathptr = &binpath[i];
        z = (char *)(ucz+((binpathptr)->accession ) );
        if (strcmp(acc,z) == 0)
	{
	    o2g = binpathptr->offset2geneids;
            if (o2g<=0) { z2 = (char *)0; break; }
            SEXP ret = PROTECT(allocVector(STRSXP, binpathptr->numgenes));
            iptr = (int *)(ucz + o2g);
            for (j=0 ; j<binpath[i].numgenes ; j++)  // for each gene for this pathway
            {
		tmphugo[0] = (char)0;
                geneid = *(iptr+j);
                Xgenerec.geneid = geneid;
                Xgenerec_ptr = bsearch(&Xgenerec,&bingene[0],numbingenes,sizeof(struct bingenetype),cmp_bingene);
                if (Xgenerec_ptr)
                    strcpy(tmphugo, Xgenerec_ptr->hugo);
                SET_STRING_ELT(ret, j, mkChar(tmphugo));
            }
            UNPROTECT(1);
	    return ret;
        }
    }
    return (SEXP)0;
}

SEXP l2pwcats (SEXP lst, SEXP catsarg, SEXP fpath)
{
   char path[PATH_MAX];
   char cats[PATH_MAX];
   int lastslash;
   int i;
   int len;
   char **z;

   user_universe_flag = 0;
   catspat=0;
   user_universe_flag = 0;
   len = length(lst);
   strncpy(path,CHAR(STRING_ELT(fpath, 0)),PATH_MAX-2);
   strncpy(cats,CHAR(STRING_ELT(catsarg, 0)),PATH_MAX-2);
   parsecats(cats); // set catpats
   z = (char **)malloc(sizeof(char *)*len);
   if (!z)
        return (SEXP) -1;
   for (i = 0; i < len; i++)
       *(z+i) = strdup(CHAR(STRING_ELT(lst, i)));
   lastslash = -1;
   for (i=0;path[i];i++)
   {
       if (path[i] == '/') lastslash = i;
   }
   if (lastslash > 0) path[lastslash] = (char)0;

   strcpy(exedir,path);
   strcat(exedir,"/");

   l2p_init_R();
   return l2p_core(1,len, z, (void *)0,(void *)0,0);
}


SEXP l2pmsig(SEXP lst, SEXP fpath)
{
   char path[PATH_MAX];
   int lastslash;
   int i;
   int len;
   char **z;


   user_universe_flag = 0;
   len = length(lst);
   strncpy(path,CHAR(STRING_ELT(fpath, 0)),PATH_MAX-2);
   z = (char **)malloc(sizeof(char *)*len);
   if (!z)
   {
        return (SEXP) -1;
   }
   for (i = 0; i < len; i++)
   {
       *(z+i) = strdup(CHAR(STRING_ELT(lst, i)));
   }
  lastslash = -1;
  for (i=0;path[i];i++)
  {
      if (path[i] == '/') lastslash = i;
  }
  if (lastslash > 0) path[lastslash] = (char)0;

  strcpy(exedir,path);
  strcat(exedir,"/");

  l2p_init_R();
  return l2p_core(1,len, z, (void *)0,(void *)0,1);
}

SEXP l2pmsigwcats(SEXP lst, SEXP catsarg, SEXP fpath)
{
   char cats[PATH_MAX];
   char path[PATH_MAX];
   int lastslash;
   int i;
   int len;
   char **z;


   user_universe_flag = 0;
   catspat=0;
   len = length(lst);
   strncpy(path,CHAR(STRING_ELT(fpath, 0)),PATH_MAX-2);
   strncpy(cats,CHAR(STRING_ELT(catsarg, 0)),PATH_MAX-2);
   parsecats(cats); // set catpats
   z = (char **)malloc(sizeof(char *)*len);
   if (!z)
   {
        return (SEXP) -1;
   }
   for (i = 0; i < len; i++)
   {
       *(z+i) = strdup(CHAR(STRING_ELT(lst, i)));
   }
  lastslash = -1;
  for (i=0;path[i];i++)
  {
      if (path[i] == '/') lastslash = i;
  }
  if (lastslash > 0) path[lastslash] = (char)0;

// hardwire for tesing strcpy(exedir,"/Users/finneyr/R/libs/l2p/extdata/");
  strcpy(exedir,path);
  strcat(exedir,"/");

  l2p_init_R();
  return l2p_core(1,len, z, (void *)0,(void *)0,1);
}

SEXP l2pu(SEXP lst, SEXP ulst, SEXP fpath )
{
   char path[PATH_MAX];
   int lastslash;
   int i;
   int len;
   char **z;

   user_universe_flag = 1;
   catspat=0;
   if (!lst)
       return (SEXP)-1;
   if (!ulst)
       return (SEXP)-2;
   len = length(lst);
   strncpy(path, CHAR(STRING_ELT(fpath, 0)),PATH_MAX-2);
   z = (char **)malloc(sizeof(char *)*len);
   if (!z)
       return (SEXP)-3;
   for (i = 0; i < len; i++)
   {
       *(z+i) = strdup(CHAR(STRING_ELT(lst, i)));
   }
   lastslash = -1;
   for (i=0;path[i];i++)
   {
      if (path[i] == '/') lastslash = i;
   }
   if (lastslash > 0) path[lastslash] = (char)0;

   strcpy(exedir,path);
   strcat(exedir,"/");

    char s[100];
    memset(s,0,sizeof(s)); 
    int2bin(catspat,s);
// fprintf(stderr,"rpf BEFORE  l2p_init_R , in catspat=%d=0x%x %s\n",catspat,catspat,s); 
    l2p_init_R();
    memset(s,0,sizeof(s)); 
    int2bin(catspat,s);
// fprintf(stderr,"rpf after  l2p_init_R , in catspat=%d=0x%x %s\n",catspat,catspat,s); 
   return l2p_core(1,len, z,ulst,(void *)0,0);
}

SEXP l2pcust(SEXP glst, SEXP clst, SEXP custpwnamearg,SEXP fpath )
{
   char path[PATH_MAX];
   int lastslash;
   int i;
   int len;
   char **zg; // user input gene list 
   char **zc; // user input custom pathway list of genes

   if (!glst) return (SEXP)-1;
   if (!clst) return (SEXP)-2;

   customflag = 1;
   catspat = 0;
   len = length(glst);
   zg = (char **)malloc(sizeof(char *)*len);
   if (!zg) return (SEXP) -3;
   for (i = 0; i < len; i++) *(zg+i) = strdup(CHAR(STRING_ELT(glst, i)));

   numcustom = length(clst);
   zc = (char **)malloc(sizeof(char *)*numcustom);
   if (!zc) return (SEXP)-4;
   for (i = 0; i < numcustom; i++) *(zc+i) = strdup(CHAR(STRING_ELT(clst, i)));

   strncpy(custom_name, CHAR(STRING_ELT(custpwnamearg, 0)),255);

   lastslash = -1;
   strncpy(path, CHAR(STRING_ELT(fpath, 0)),PATH_MAX-2);
   for (i=0;path[i];i++) { if (path[i] == '/') lastslash = i; }
   if (lastslash > 0) path[lastslash] = (char)0;
   strcpy(exedir,path);
   strcat(exedir,"/");

#if 0
   char s[100];
   memset(s,0,sizeof(s)); 
   int2bin(catspat,s);
#endif
   l2p_init_R();
   return l2p_core(1,len, zg,(void *)0,zc,0);
}

SEXP l2puwcats(SEXP lst, SEXP ulst, SEXP catsarg, SEXP fpath )
{
   char path[PATH_MAX];
   char cats[PATH_MAX];
   int lastslash;
   int i;
   int len;
   char **z;

   user_universe_flag = 1;
   catspat=0;
//   fprintf(stderr,"in l2puwcats 1\n"); fflush(NULL);
   if (!lst)
       return (SEXP)-1;
   if (!ulst)
       return (SEXP)-2;
   len = length(lst);
   strncpy(path, CHAR(STRING_ELT(fpath, 0)),PATH_MAX-2);
   strncpy(cats,CHAR(STRING_ELT(catsarg, 0)),PATH_MAX-2);
   parsecats(cats); // set catpats
   z = (char **)malloc(sizeof(char *)*len);
   if (!z)
       return (SEXP)-3;
   for (i = 0; i < len; i++)
   {
       *(z+i) = strdup(CHAR(STRING_ELT(lst, i)));
   }
   lastslash = -1;
   for (i=0;path[i];i++)
   {
      if (path[i] == '/') lastslash = i;
   }
   if (lastslash > 0) path[lastslash] = (char)0;

   strcpy(exedir,path);
   strcat(exedir,"/");

   l2p_init_R();
   return l2p_core(1,len, z,ulst,(void *)0,0);
}


#if 0
SEXP l2pumsig(SEXP lst, SEXP ulst, SEXP fpath )
{
   char path[PATH_MAX];
   int lastslash;
   int i;
   int len;
   char **z;

   if (!lst)
   {
       return (SEXP)-1;
   }
   if (!ulst)
   {
       return (SEXP)-2;
   }
   user_universe_flag = 1;
   len = length(lst);
   strncpy(path, CHAR(STRING_ELT(fpath, 0)),PATH_MAX-2);
   z = (char **)malloc(sizeof(char *)*len);
   if (!z)
   {
       return (SEXP)-3;
   }
   for (i = 0; i < len; i++)
   {
       *(z+i) = strdup(CHAR(STRING_ELT(lst, i)));
   }
   lastslash = -1;
   for (i=0;path[i];i++)
   {
      if (path[i] == '/') lastslash = i;
   }
   if (lastslash > 0) path[lastslash] = (char)0;

   strcpy(exedir,path);
   strcat(exedir,"/");

   l2p_init_R();
   return l2p_core(1,len, z,ulst,1);
}
#endif

#if 0
SEXP l2pmsigwcatsu(SEXP lst, SEXP ulst, SEXP catsarg, SEXP fpath )
{
   char cats[PATH_MAX];
   char path[PATH_MAX];
   int lastslash;
   int i;
   int len;
   char **z;

   if (!lst)
       return (SEXP)-1;
   if (!ulst)
       return (SEXP)-2;
   user_universe_flag = 1;
   len = length(lst);
   strncpy(path, CHAR(STRING_ELT(fpath, 0)),PATH_MAX-2);
   strncpy(cats,CHAR(STRING_ELT(catsarg, 0)),PATH_MAX-2);
   parsecats(cats); // set catpats
   z = (char **)malloc(sizeof(char *)*len);
   if (!z)
       return (SEXP)-3;
   for (i = 0; i < len; i++)
       *(z+i) = strdup(CHAR(STRING_ELT(lst, i)));
   lastslash = -1;
   for (i=0;path[i];i++)
   {
      if (path[i] == '/') lastslash = i;
   }
   if (lastslash > 0) path[lastslash] = (char)0;

   strcpy(exedir,path);
   strcat(exedir,"/");

   l2p_init_R();
   return l2p_core(1,len, z,ulst,1);
}
#endif

#else
#if __MACH__
// using mac os 
#include <libproc.h>
#endif
void get_this_executable_path(char *puthere,int size)
{
    int i;
    int lastslash = 0;

    *puthere = (char)0;
 // if apple ... else linux ...
#if __MACH__
// /proc_pidpath/
    pid_t pid;
    pid = getpid();
    int ret;
    ret = proc_pidpath (pid, puthere, PATH_MAX);
    if ( ret <= 0 ) {
        fprintf(stderr, "PID %d: proc_pidpath ();\n", pid);
        fprintf(stderr, "    %s\n", strerror(errno));
    } else { // success
        // printf("proc %d: %s\n", pid, puthere);
    }
// does not work    strcpy(rlinfo,"/proc/curproc/file");
//  alternate method:  (_NSGetExecutablePath(path, &size) == 0)
#else
    char rlinfo[PATH_MAX];
    strcpy(rlinfo,"/proc/self/exe");
    if (readlink(rlinfo, puthere,PATH_MAX) == -1)
    {
         fprintf(stderr,"ERROR Can not access full path of (this!) executable\n");
                     // what to do ? not sure.
         return;
    }
#endif
    for (i=0;puthere[i];i++)
        if (puthere[i] == '/') lastslash = i;
    puthere[lastslash+1] = (char)0;
    return;
// readlink("/proc/curproc/file", buf, bufsize) (FreeBSD)
// readlink("/proc/self/path/a.out", buf, bufsize)
// On Windows: use GetModuleFileName(NULL, buf, bufsize)
}



#if WEBASSEMBLY
// url encode/decode stuff from http://www.geekhideout.com/urlcode.shtml

char from_hex(char ch) { /* Converts a hex character to its integer value */
  return isdigit(ch) ? ch - '0' : tolower(ch) - 'a' + 10;
}

/* Converts an integer value to its hex character*/
char to_hex(char code) {
  static char hex[] = "0123456789abcdef";
  return hex[code & 15];
}

/* Returns a url-encoded version of str */
/* IMPORTANT: be sure to free() the returned string after use */
char *url_encode(char *str) {
  char *pstr = str, *buf = malloc(strlen(str) * 3 + 1), *pbuf = buf;
  while (*pstr) {
    if (isalnum(*pstr) || *pstr == '-' || *pstr == '_' || *pstr == '.' || *pstr == '~') 
      *pbuf++ = *pstr;
    else if (*pstr == ' ') 
      *pbuf++ = '+';
    else 
      *pbuf++ = '%', *pbuf++ = to_hex(*pstr >> 4), *pbuf++ = to_hex(*pstr & 15);
    pstr++;
  }
  *pbuf = '\0';
  return buf;
}

/* Returns a url-decoded version of str */
/* IMPORTANT: be sure to free() the returned string after use */
char *url_decode(char *str) {
  char *pstr = str, *buf = malloc(strlen(str) + 1), *pbuf = buf;
  while (*pstr) {
    if (*pstr == '%') {
      if (pstr[1] && pstr[2]) {
        *pbuf++ = from_hex(pstr[1]) << 4 | from_hex(pstr[2]);
        pstr += 2;
      }
    } else if (*pstr == '+') { 
      *pbuf++ = ' ';
    } else {
      *pbuf++ = *pstr;
    }
    pstr++;
  }
  *pbuf = '\0';
  return buf;
}


char *injectionunalloweds_soft[] =  // case not important, we will check for upper and lower
{
    "<", 
    ">", 
    "<%00'"  ,    // MS exploit  ( http://www.securiteam.com/windowsntfocus/6R00R008KY.html )
    "%20'"  , 
    "%20%27" // just don't allow " '" , 
    "%22-alert",
    "%22-alert%2827%29-%22" ,
    "%27+" , 
    " %27" // just don't allow " '" , 
    "%27+OR", 
    "%28select" ,  
    "%5C'"  , 
    "alert", 
    "alert(",
    "alert%2827", 
    "alert%2827%29-%22", 
    "delete", 
    "drop", 
    "having ",
    "having%20",
    "href", 
    "http", 
    "iframe", 
    "<img", 
    "img src",
    "import+url", 
    "insert", 
    "javascript", 
    "onerror", 
    "onclick", 
    "onmouseover",
    "console",
    " or ", 
    " OR ", 
    "OR+%27", 
    "script", 
    "select", 
    "show tables", 
    "update", 
    "onAbort" , // - The user aborts the loading of an image
    "onBlur" , // - form element loses focus or when a window or frame loses focus.
    "onChange" , // - select, text, or textarea field loses focus and its value has been modified.
    "onClick" , // - object on a form is clicked.
    "onDblClick" , // - user double-clicks a form element or a link.
    "onDragDrop" , // - user drops an object (e.g. file) onto the browser window.
    "onError" , // - loading of a document or image causes an error.
    "onFocus" , // - window, frame, frameset or form element receives focus.
    "onKeyDown" , // - user depresses a key.
    "onKeyPress" , // - user presses or holds down a key.
    "onKeyUp" , // - user releases a key.
    "onLoad" , // - browser finishes loading a window or all of the frames within a frameset.
    "onMouseDown" , // - user depresses a mouse button.
    "onMouseMove" , // - user moves the cursor.
    "onMouseOut" , // - cursor leaves an area or link.
    "onMouseOver" , // - cursor moves over an object or area.
    "onMouseUp" , // - user releases a mouse button.
    "onMove" , // - user or script moves a window or frame.
    "onReset" , // - user resets a form.
    "onResize" , // - user or script resizes a window or frame.
    "onSelect" , // - user selects some of the text within a text or textarea field.
    "onSubmit" , // - user submits a form.
    "onUnload" , // - user exits a document. 
    "Object" ,  //
    "button" ,  	 //onBlur()1, onClick(), onFocus()1
    "checkbox" ,  //	onBlur()1, onClick(), onFocus()1
    "fileupload" , // 	onBlur(), onChange()2, onFocus()
    "form"  ,	// onSubmit()
    "link"  ,	// onClick(), onMouseOver()
    "password"  ,	// onBlur(), onChange()3, onFocus()
    "radio"  ,	// onBlur()1, onClick(), onFocus()1
    "reset"  ,	// onBlur()1, onClick()4, onFocus()1
    "submit"  ,	// onBlur()1, onClick()6, onFocus()1
    "text" ,	// onBlur(), onChange(), onFocus()
    "textarea"	 ,// onBlur(), onChange(), onFocus()
    "window"	,// onLoad(), onUnload()
// recommended by IBM appscan ...
    "|",      // (pipe sign)
    "&",      // (ampersand sign)
    ";",      // (semicolon sign)
    "$",      // (dollar sign)
    "%",      // (percent sign)
    "@",      // (at sign)
    "'",      // (single apostrophe)
    "\"",     // (quotation mark)
    "\\'",    // (backslash-escaped apostrophe) [10] \" // (backslash-escaped quotation mark)
    "<>",     // (triangular parenthesis) [12] // () // (parenthesis)
    "\xd",     // (Carriage return, ASCII 0x0d)
    "\xa",     // (Line feed, ASCII 0x0a)
    ",",      // (comma sign)
    "\\",     // (backslash)
    "area" , 
    "document" , 
    "frame" , 
    "image" , 
    "layer" , 
    "xmlHTTPRequest" , 
    "fetch" , 
    (char *)0
};


char *injectionunalloweds_hard[] =  // case not important, we will check for upper and lower
{
    "+",      // (plus sign)  used by gdc token  at position 810 (tricky to find)
    (char *)0
};


char *case_insensitive_strstr(char *haystack, char *needle) // stolen from internet 
{
    if ( !*needle )
    {
        return haystack;
    }
    for ( ; *haystack; ++haystack )
    {
        if ( toupper(*haystack) == toupper(*needle) )
        {
        /* * Matched starting char -- loop through remaining chars.  */
            char *h, *n;
            for ( h = haystack, n = needle; *h && *n; ++h, ++n )
            {
                if ( toupper(*h) != toupper(*n) )
                {
                    break;
                }
            }
            if ( !*n ) /* matched all of 'needle' to null termination */
            {
                return haystack; /* return the start of the match */
            }
        }
    }
    return 0;
}


int ishex(char c)
{
    if (isdigit(c)) return 1;
    else if ((toupper(c)) == 'A') return 1;
    else if ((toupper(c)) == 'B') return 1;
    else if ((toupper(c)) == 'C') return 1;
    else if ((toupper(c)) == 'D') return 1;
    else if ((toupper(c)) == 'E') return 1;
    else if ((toupper(c)) == 'F') return 1;
    return 0;
}


void cgi_normalize(char *s)
{
    int j;
    int kickout = 0;
    int tmpi;
    char *z;
    char *sofar = s;
    int offset = 0;
    char tmp[4096];
/*
testtrings /cgi-bin/hgNear?org=Human&db=hg18&near_search=&near_order=>%22%27><img%20src%3d%22javascript:alert(64868)%22>&hgsid=17811
*/

    while (1)
    {
        if (kickout++ >= 1000) break;
        z = strstr(sofar,"%");
        if (!z) break;
        offset = 0;
        if ((*(z+1)=='2')&&(*(z+2)=='5'))  // handle special case of 0x25 (percent sign) 
        {
           *z = (char)'%';
           offset = 3;
        }
        else
        {
            if (ishex(*(z+1)))
            {
// sprintf(m,"in cgi_normalize - 3 - ishex = %c",*(z+1)); zdebug(m); 
               tmp[0] = *(z+1);
               offset = 2;
            }
// sprintf(m,"in cgi_normalize - 3 "); zdebug(m); 
            tmp[1] = (char)0;
            if (ishex(*(z+2)))
            {
// sprintf(m,"in cgi_normalize - 4 - ishex = %c",*(z+2)); zdebug(m); 
               tmp[1] = *(z+2);
               offset = 3;
            }
// sprintf(m,"in cgi_normalize - 7 "); zdebug(m); 
            tmp[2] = (char)0;
            sscanf(tmp,"%x",&tmpi);
//sprintf(m,"in cgi_normalize - 8 ,tmp=[%s] tmpi=%d",tmp,tmpi); zdebug(m); 
            sprintf(tmp,"%c",tmpi);
// sprintf(m,"in cgi_normalize - 8.1 tmp=[%s]",tmp); zdebug(m); 
           *z = (char)tmpi;
        }
        j = 0;
// sprintf(m,"in cgi_normalize - 9 "); zdebug(m); 
// sprintf(m,"in cgi_normalize - 9.01 z+offset+j=%s",z+offset+j); zdebug(m); 
        sofar = z+1;
        while (*(z+offset+j))
        {
            if (kickout++ >= 1000) break;
            *(z+1+j) = *(z+offset+j);
// sprintf(m,"in cgi_normalize - 9.2 ,z now=[%s]",z); zdebug(m); 
// sprintf(m,"in cgi_normalize - 9.3 ,s now=[%s]",s); zdebug(m); 
            j++;
        }
// sprintf(m,"in cgi_normalize - 10 "); zdebug(m); 
        *(z+1+j) = (char)0;
//sprintf(m,"in cgi_normalize - temp result = [%s]",s); zdebug(m); 
    }
//sprintf(m,"end cgi_normalize - string is [%s]",s); zdebug(m);
    return;
}

// Prevent "injection" exploits : sql, remote command execution, shell, xpath, ldap ,etc.
// Now, this is webassembly ... so it is less of a threat.  But clean up anyway to make it pass vulnerability scans.
int scrub_input_string(char buffarg[], int hard_flag) 
{
    size_t len = 0;
    int j = 0;
    char *z;
    int gotbad_flag = 0;
    int ret = 0;

// new anti-hack stuff ...
    // cgi_normalize(buffarg);
    gotbad_flag = 1;
    while ( gotbad_flag == 1 )
    {
        gotbad_flag = 0;
        for (j=0 ;injectionunalloweds_soft[j] != (char *)0 ; j++)
        {
            z = case_insensitive_strstr(buffarg,(char *)injectionunalloweds_soft[j]);
            if(z)
            {
                len = strlen(injectionunalloweds_soft[j]);
                strcpy(z,z+len);
                gotbad_flag = 1;
                ret = -1;
                break; // kick out of inner for loop, continue while
            }
        }
    }
    if (hard_flag) // look harder
    {
        gotbad_flag = 1;
        while ( gotbad_flag == 1 )
        {
            gotbad_flag = 0;
            for (j=0 ;injectionunalloweds_hard[j] != (char *)0 ; j++)
            {
                z = case_insensitive_strstr(buffarg,(char *)injectionunalloweds_hard[j]);
                if(z)
                {
                    len = strlen(injectionunalloweds_hard[j]);
                    strcpy(z,z+len);
                    gotbad_flag = 1;
                    ret = -1;
                    break; // kick out of inner for loop, continue while
                }
            }
        }
    }
    return ret;
}

#define MAXTOK 206618
char genes[MAXTOK];
// justification for size : cut -f10  pathworks.txt  | tr " " "\n" | sort | uniq  | awk '{printf "%s ",$1}' | wc =  0   28991  206616


int usr_msg(char *msg)
{
    char s[512];
    sprintf(s,"document.getElementById('usrmsg').innerHTML=\"%s\"",msg);
    emscripten_run_script(s);
    return 0;
}


int EMSCRIPTEN_KEEPALIVE wasm_string_to_c(char* p)
{
#if 0
    char val_id[MAXTOK];
    char val[MAXTOK];
#else
    char *val_id;
    char *val;
#endif
    int i,j;
    char c;
    int ret;

    ret = 0;
    val_id = malloc((size_t)MAXTOK);
    val = malloc((size_t)MAXTOK);

    val_id[0] = val[0] = (char)0;

    if (!p)
    {
        fprintf(stderr,"in wasm_string_to_c ERROR: null passed in\n"); 
        ret = -1;
	goto END_WS2C;
    }
// yyy 
    for (i=0 ; *(p+i) && (i<(MAXTOK-1)) ; i++)
    {
       c = *(p+i);
       if (c == ' ') break;
       val_id[i] = (char)c;
       val_id[i+1] = (char)0;
    }
    i++;
    j = 0;
    for ( ; *(p+i) && (j <(MAXTOK-1)) ; i++)
    {
       c = *(p+i);
       val[j] = (char)c;
       val[j+1] = (char)0;
       j++;
    }

#if 1
// debug 
fprintf(stderr,"in wasm_string_to_c valid=%s\n",val_id); 
fprintf(stderr,"in wasm_string_to_c val=%s\n",val); 
#endif

    if (strcmp(val_id,"genes") == 0)
        strlcpy(genes,val,sizeof(genes));

#if TESTBUTTON 
    else if (strcmp(val_id,"test") == 0)
    {
        strlcpy(teststring,val,sizeof(teststring));
    }
#endif
#if 0
    int status;
    status = scrub_input_string(val,0); // security screen 
    if (status == -1)
    {
        usr_msg("Suspect Input Modified");
    }
#endif

END_WS2C:
    if (val_id) free(val_id);
    if (val) free(val);

    return ret;
}


    // mallocs genelist, must free if returned value
char **create_gene_list_for_wasm(char s[], int *numgenesptr) //returns genelist[] and set numgenesptr 
{
    char tmps[126]; // max gene name length is 22 = DTX2P1-UPK3BP1-PMS2P11
    int i,j;
    char ch;
    char **z;
    int tmpnumingenes;

// 2 pass.  1st pass is count 'em, 2nd pass is process them 
    
    z = (void *)0;
    tmpnumingenes = 0;
    tmps[0] = (char)0;
    for (j=i=0;s[i];i++)
    {
    	ch = s[i];
    	if (ch <= 32)
	{
            if (tmps[0]) tmpnumingenes++;
	    tmps[0] = (char)0;
	    j = 0;
	    continue;
	}
	tmps[j++] = ch;
	tmps[j] = (char)0;
	if (j > 32) 
	{ 
	   fprintf(stderr,"ERROR, string too big. in create_gene_list_for_wasm()\n"); 
           usr_msg("bad input detected");
	   j = 0;
	} 
    }
    tmpnumingenes++;   

    // second pass, we now have the number of genes
    z = (char **)malloc(sizeof(char *)*tmpnumingenes);
    tmpnumingenes = 0;
    tmps[0] = (char)0;
    for (j=i=0;s[i];i++)
    {
    	ch = s[i];
    	if (ch <= 32)
	{
            if (tmps[0]) { *(z+tmpnumingenes) = strdup(tmps); tmpnumingenes++;}
	    tmps[0] = (char)0;
	    j = 0;
	    continue;
	}
	tmps[j++] = ch;
	tmps[j] = (char)0;
	if (j > 32)
	{ 
	   fprintf(stderr,"ERROR, string too big. in create_gene_list_for_wasm() 2\n"); 
           usr_msg("bad input detected");
	   j = 0;
	} 
    }
        // process any remaining 
    if (tmps[0]) { *(z+tmpnumingenes) =strdup(tmps); tmpnumingenes++; }
    *numgenesptr = tmpnumingenes;
    return z;
}


#define MAXSCRIPT 2000000
int EMSCRIPTEN_KEEPALIVE wasmfunc(int code)
{
#if 0
    char sayinfo[512];
    char msg[512];
    FILE *fpo;
    int hits = 0;
    char chr[512]; 
    unsigned int start;
    unsigned int end;
    size_t tsize;
    int len;
#endif
    char *script = (char *)0;
    char s[512];
    int status;

fprintf(stderr,"start wasmfunc, code=%d\n",code);

#define SETUPSCRIPT() if (script) free(script); script = malloc((size_t)MAXSCRIPT); \
if (!script) { fprintf(stderr,"ERROR: in wasmfunc,code=%d, Can not malloc %d bytes.\n",code,MAXSCRIPT);return -2;} \
*(script) = (char)0;
    if (code == 1)
    {
fprintf(stderr,"in wasmfunc, code == 1 initialize.\n");
        SETUPSCRIPT()
        sprintf(s,"document.getElementById('arena').innerHTML=''"); strcat(script,s);
        emscripten_run_script(script);
        *(script) = (char)0;
        sprintf(s,"var mydb=document.getElementById('dashboard');"); strcat(script,s);
        sprintf(s,"mydb.innerHTML=\"");           strcat(script,s);
        sprintf(s,"Enter GENE SYMBOLS:<br>");     strcat(script,s);
        sprintf(s,"<form name='getgenes' onSubmit='JavaScript:SumbitGenes(this.form)'>"); strcat(script,s); 
        sprintf(s,"<textarea id='genes' rows='10' cols='160'>");  strcat(script,s);
        sprintf(s,"</textarea><br>");             strcat(script,s);
        sprintf(s,"<span class='button'><INPUT TYPE=BUTTON ID='Submit_Genes_Button' OnClick='SubmitGenes(this.form); return false;' VALUE='%s'></span>","Submit"); strcat(script,s); 
        sprintf(s,"<br>"); strcat(script,s);
        sprintf(s,"</form>"); strcat(script,s); 
        sprintf(s,"<br>Enter HUGO gene names<br>"); strcat(script,s); 
        sprintf(s,"\";"); strcat(script,s);  // end the quote
// fprintf(stderr,"script=[%s]\n",script);
        emscripten_run_script(script);
fprintf(stderr,"Should have displayed getgenes menu"); 
        strcpy(exedir,"preload/");
    }
    else if (code == 2)
    {
	char **genelist;
	int numingenes;
	numingenes = 0;
        fprintf(stderr,"wasmfunc in l2p.c, code is 2 \n"); fflush(stderr);
	genelist=create_gene_list_for_wasm(genes,&numingenes); // return genelist[] and set numingenes 

        fprintf(stderr,"num ingenes genes are %d\n",numingenes); fflush(stderr);
        fprintf(stderr,"genes are %s\n",genes); fflush(stderr);
/*
        int k;
	for (k=0;k<numingenes;k++)
		fprintf(stderr,"gene %d = %s\n",k,genelist[k]);
*/
        init_display_results();
        status = l2p_core( 0, numingenes,genelist, 0); // frees genelist (?) 
// -rw-r--r-- 1 rfinney rfinney 23504493 Sep 11 18:06 joke
fprintf(stderr,"after l2pcore\n"); fflush(stderr); 
        display_results();    
    }

       // -- wasmfunc() function wrap up ...
    if (script) { free(script); script = (char *)0; }
fprintf(stderr,"return from wasmfunc code=%d\n",code);
    return 0;

}


   // The "main loop" function.
void one_iter()
{
  // process input
  // render to screen
}
int main(int argc, char ** argv)
{
   fprintf(stderr,"in l2p main wasm - Hello World.\n");
   fprintf(stderr,"debug wasm sz sizeof(struct binpathouttype))=%zu\n",sizeof(struct binpathouttype)); fflush(stderr);
   fprintf(stderr,"debug sz sizeof(struct bingenetype))=%zu\n",sizeof(struct bingenetype)); fflush(stderr);
   l2p_init_C(0,0,(char **)0);
   // if (catspat == 0) category_set_all(&catspat);
   category_set_all(&catspat);
   EM_ASM( allReady() );
   emscripten_set_main_loop(one_iter, 60, 1);
#if 0
  while (1) {
    one_iter();
    // Delay to keep frame rate constant (using SDL)
    SDL_Delay(time_to_next_frame());
  }
#endif
}

#else

static int l2p_run_for_C(int argc,char *argv[])
{
    l2p_init_C(0,argc,argv);
    get_this_executable_path(exedir,PATH_MAX);
// fprintf(stderr,"rpf in l2p_run_for_C before get_this_executable_path pats=0x%x\n",catspat); fflush(NULL);
    l2p_core(0, 0,(void *)0,0);
    return 0;
}
int main(int argc,char *argv[])
{
#if 0
	 // debug, record size not same in various compilers
    fprintf(stderr,"debug sz sizeof(struct binpathouttype))=%zu\n",sizeof(struct binpathouttype)); fflush(stderr);
    fprintf(stderr,"debug sz sizeof(struct bingenetype))=%zu\n",sizeof(struct bingenetype)); fflush(stderr);
#endif
    return l2p_run_for_C(argc,argv);
}
#endif

#endif

