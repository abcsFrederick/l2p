
/*
vi l2p2.c ; make
gcc --Wall -Os -o l2p2 pwgenes.c small.c


     1  pval
     2  fdr
     3  ratio                      if postive, genes are OVER REPRESENTED, if negative genes are UNDER REPRESENTED
     4  pwhitcount                 number of genes hit in pathway
     5  pwnohitcount               pathway number of genes in the pathway
     6  inputcount                  total count of user genes (user input)
     7  pwuniverseminuslist        total number of unique genes in all pathways
     8  pathwayaccessionidentifier canonical accession ( if availible, otherwise assigned by us )
     9  category                   KEGG,REACTOME,GO,PANT(=PANTHER),PID=(pathway interaction database)  *was "soruce"*
    10  pathwayname                Name of pathway
    11  pathwaytype genes_space_separated   HUGO genes from user that hit the pathway


The Fisher’s exact test on the permutation table is basically stand-alone, it doesn’t need a permutation test initially.  But it looks like I’m testing something different from what is usually tested; for my test the total number of genes in the pathway isn’t relevant.  Good, I want to do something different.  

The contingency table: So I can think clearly I’ll set this up the way I’m used to (from epidemiology, first column is no disease, second is disease; first row in no exposure, second is exposure).  For us “disease” means occurring in the pathway in question; “exposure” means being on the investigator’s list of genes. 

First without the correction:
A:  Count of genes in the universe but not on the list and not in the pathway
B:  Count of genes in the universe but not on the list, in the pathway
C:  Count of genes on the list but not in the pathway
D:  Count of genes on the list and in the pathway
c d b a

Now with the correction:
B and D are unchanged.
For A and C:  Sum over the genes, the number of pathways (in the universe of pathways) each gene occurs in.
For example suppose there are 3 genes in C (must be a very short list of genes!) so in the uncorrected table the entry in C is 3.
The first gene occurs in 5 pathways, the second in 2, the third in 10.  The entry in C is 17.  
Same for A, but this will always be a sum over a large number of genes.

The sum of the entries in the table will now be larger, so the table will need to be corrected, but ignore this for now. 

so ...
   UUUUUUUUUUUUUUUUUUUUUUUUUUUUU 
   U                           U 
   U universe   PPPPPPPPPPPP   U 
   U            P          P   U 
   U            P pathway  P   U 
   U            P          P   U 
   U       LLLLLLLLLLLLLL  P   U 
   U       L    P       L  P   U 
   U       L    P hits  L  P   U 
   U       L    P       L  P   U 
   U       L    PPPPPPPPLPPP   U 
   U       L            L      U 
   U       L  list      L      U 
   U       L            L      U 
   U       LLLLLLLLLLLLLL      U 
   U                           U 
   UUUUUUUUUUUUUUUUUUUUUUUUUUUUU 

   UUUUUUUUUUUUUUUUUUUUUUUUUUUUU    UUUUUUUUUUUUUUUUUUUUUUUUUUUUU    UUUUUUUUUUUUUUUUUUUUUUUUUUUUU 
   U                           U    U                           U    U                           U 
   U universe                  U    U            PPPPPPPPPPPP   U    U                           U 
   U                           U    U            P          P   U    U                           U 
   U                           U    U            P pathway  P   U    U                           U 
   U                           U    U            P          P   U    U                           U 
   U                           U    U            P          P   U    U       LLLLLLLLLLLLLL      U 
   U                           U    U            P          P   U    U       L            L      U 
   U                           U    U            P          P   U    U       L            L      U 
   U                           U    U            P          P   U    U       L            L      U 
   U                           U    U            PPPPPPPPPPPP   U    U       L            L      U 
   U                           U    U                           U    U       L            L      U 
   U                           U    U                           U    U       L  list      L      U 
   U                           U    U                           U    U       L            L      U 
   U                           U    U                           U    U       LLLLLLLLLLLLLL      U 
   U                           U    U                           U    U                           U 
   UUUUUUUUUUUUUUUUUUUUUUUUUUUUU    UUUUUUUUUUUUUUUUUUUUUUUUUUUUU    UUUUUUUUUUUUUUUUUUUUUUUUUUUUU 

A = u - p - h
B = u - l 
C = l - h 
D = h

dcba

see https://www.biostars.org/p/252937/ on how DAVID does it.

list=300 hits=3  pw=40 genome=30001
         usergenes     genome
ipw         3-1         40
notinpw     297       29960

a=hits
b=list-hits
c=list
d=u-list

*/
#define NELSON 0


#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <stdint.h>
#include <string.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>
#include <unistd.h>

#include "pathworks.h"
#ifdef WEBASSEMBLY
#include "small.h"
#else

#if L2PUSETHREADS
#include <pthread.h>
#endif

#include "big.h"
#endif


extern unsigned short int pwgenes[];
extern struct smallgenetype genes[];
extern struct pwtype pws[];
extern int numpws;
extern int numgenes;
extern int numpwgenes;

struct smallgenetype *by_egids; // a copy of "genes" ,but sorted by egid (entrez gene id )



#if 0
 // debug routine
void dump_used_paths(struct used_path_type *u, int num, char *msg)
{
    struct used_path_type *uptr; // used path pointer
    int i,j;
    char *z;

fprintf(stderr,"in dump_upsed_paths() num=%d msg=[%s]\n",num,msg); fflush(stderr); 
    for (i=0 ; i<100 ; i++)   // for each line of custom file
    {
        uptr = (u+i);
        fprintf(stderr,"acc %d %s\n",i,uptr->acc);  fflush(stderr); 
        fprintf(stderr,"name %d %s\n",i,uptr->name); 
        fprintf(stderr,"numgenes %d %u\n",i,uptr->numgenes); 
        fprintf(stderr,"numfixed %d %u\n",i,uptr->numfixedgenes); 
        fprintf(stderr,"genehits %d %p\n",i,uptr->genehits); 
        fprintf(stderr,"egids %d %p\n",i,uptr->egids); 
        for (j=0;j<10;j++)
       // for (j=0;j<uptr->numfixedgenes;j++)
        {
            z = egid2hugo(*(uptr->egids+j));
            fprintf(stderr,"gene %d %d = %u = %s [%s]\n",i,j,*(uptr->egids+j),z,msg);
        }
        fflush(stderr);
    }
    return;
}
#endif

char *type2string(int type)
{
   static char functional_set[] = "functional_set";
   static char pathway  [] = "pathway";
   static char structural_complex  [] = "structural_complex";
   static char custom_string  [] = "custom";
   static char null_info  [] = "NA";

   if (type == 1) return &functional_set[0];
   else if (type == 2) return &pathway[0];
   else if (type == 3) return &structural_complex[0];
   else if (type == 4) return &custom_string[0];
   return &null_info[0];
}

int cmp_hugo(const void *a, const void *b)
{
    return strcmp(((struct smallgenetype *)a)->hugo, ((struct smallgenetype *)b)->hugo);;
}

int cmp_by_egid(const void *a, const void *b) // compare entrez gene id
{
    if      ( ((struct smallgenetype *)a)->egid < ((struct smallgenetype *)b)->egid ) return -1;
    else if ( ((struct smallgenetype *)a)->egid > ((struct smallgenetype *)b)->egid ) return 1;
    return 0;
}

char *egid2hugo(int egid)
{
    struct smallgenetype glocal;
    struct smallgenetype *gptr;

    glocal.egid = egid;
    gptr = (struct smallgenetype *)bsearch(&glocal,by_egids,numgenes,sizeof(struct smallgenetype),cmp_by_egid);
    if (gptr) return gptr->hugo;
    else return (void *)0;
}

unsigned int hugo2egid(char *h)
{
    struct smallgenetype glocal;
    struct smallgenetype *gptr;

    glocal.hugo = h;
    gptr = (struct smallgenetype *)bsearch(&glocal,genes,numgenes,sizeof(struct smallgenetype),cmp_hugo);
    if (gptr) return gptr->egid;
    else return (unsigned int)UINT_MAX;
}

struct smallgenetype *hugo2geneptr(char *h)
{
    struct smallgenetype glocal;
    struct smallgenetype *gptr;

    glocal.hugo = h;
    gptr = (struct smallgenetype *)bsearch(&glocal,genes,numgenes,sizeof(struct smallgenetype),cmp_hugo);
    return gptr;
}

unsigned short int hugo2usedindex(char *h)
{
    struct smallgenetype glocal;
    struct smallgenetype *gptr;
    unsigned short int ret;
    int idx;

    glocal.hugo = h;
    gptr = (struct smallgenetype *)bsearch(&glocal,genes,numgenes,sizeof(struct smallgenetype),cmp_hugo);
    if (gptr)
    {
        idx = gptr - &genes[0];
        if (idx > 20000) {fprintf(stderr,"ERROR in hub2usedindex %s gptr=%p idx=%d\n",h,gptr,idx); fflush(NULL); exit(0); }
        ret = (unsigned short int)idx;
    }
    else
    {
        ret = (unsigned short int)USHRT_MAX;
    }
    return ret;
}

int cmp_usi(const void *a, const void *b)
{
    if      ( *(unsigned short int *)a < *(unsigned short int *)b ) return -1;
    else if ( *(unsigned short int *)a > *(unsigned short int *)b ) return 1;
    return 0;
}

int cmp_ui(const void *a, const void *b)
{
    if      ( *(unsigned int *)a < *(unsigned int *)b ) return -1;
    else if ( *(unsigned int *)a > *(unsigned int *)b ) return 1;
    return 0;
}

static int cmp_double(const void *a, const void *b)
{
    if      ( *(double *)a < *(double *)b ) return -1;
    else if ( *(double *)a > *(double *)b ) return 1;
    return 0;
}

/*
ReservoirSample(S[1..n], R[1..k])
  R[1] := S[1]
  for i from 2 to k do
      j := randomInteger(1, i)  // inclusive range
      R[i] := R[j]
      R[j] := S[i]
  for i from k + 1 to n do
      j := randomInteger(1, i)  // inclusive range
      if (j <= k)
          R[j] := S[i]
*/
static inline void shuffle(unsigned int s[], int n)
{
    int i,j;
    unsigned int ui;

// for i from 0 to n−2 do
//      j ← random integer such that i ≤ j < n
//      exchange a[i] and a[j]
// or
// for i from n−1 downto 1 do
//      j ← random integer such that 0 ≤ j ≤ i
//      exchange a[j] and a[i]

    for (i=n-1;i>=1;i--)
    {
        j = rand() % i;
// fprintf(stderr,"i = %d j = %d \n",i,j); fflush(stderr); 
        ui = s[i];
        s[i] = s[j];
        s[j] = ui;
// fprintf(stderr,"here\n"); fflush(stderr); 
    }
// fprintf(stderr,"done\n"); fflush(stderr); 
    return;
}

static inline void resivoir(unsigned int s[], int n, unsigned int r[],int k)
{
    int i,j;

    r[0] = s[0];
    for (i=1;i<k;i++)
    {
        j = rand() % i;
        r[i] = r[j];
        r[j] = s[i];
    }
    for (i=k+1;i<n;i++)
    {
        j = rand() % i;
        if (j <= k)
            r[j] = s[i];
    }
    return;
}



// -- for benjamini hochberg FDR ...
struct ordertype
{
    double val;
    int order;
};

static int cmp_ordertype_by_order(const void *a, const void *b)
{
    struct ordertype *aa;
    struct ordertype *bb;
    aa = (void *)a;
    bb = (void *)b;
    if      (aa->order >  bb->order) return 1;
    else if (aa->order <  bb->order) return -1;
    return 0;
}

int cmp_ordertype_by_val_REV(const void *a, const void *b)
{
    struct ordertype *aa;
    struct ordertype *bb;
    aa = (void *)a;
    bb = (void *)b;
    if      (aa->val <  bb->val) return 1;
    else if (aa->val >  bb->val) return -1;
    // if (aa>bb) return 1; else if (aa<bb) return -1;
    return 0;
}

static void benjaminihochberg(int n,double pvals[], double returnpvals[])
{
/*
 here's the code from R that I re-imagined
                   i <- lp:1L
                   o <- order(p, decreasing = TRUE)
                   ro <- order(o)
                   pmin(1, cummin( n / i * p[o] ))[ro]
*/
    int j,k;
    struct ordertype *i;
    struct ordertype *o;
    struct ordertype *po;
    struct ordertype *cummin;
//    struct ordertype *ro;
//    struct ordertype *intermed;

    i = (struct ordertype *)malloc((sizeof(struct ordertype))*n);
    for (k=n,j=0;j<n;j++,k--) (i+j)->order=k;

#if RDEBUG
FILE *fp;
fp = fopen("test.pvals","w");
#endif
    o = (struct ordertype *)malloc((sizeof(struct ordertype))*n);
    for (j=0 ; j<n ; j++)
    {
#if RDEBUG
fprintf(fp,"%20.18f\n",pvals[j]);
#endif
        (o+j)->val=pvals[j];
        (o+j)->order=j+1;
    }
#if RDEBUG
fclose(fp);
#endif
    qsort(o,n,sizeof(struct ordertype),cmp_ordertype_by_val_REV);

#if 0
    ro = (struct ordertype *)malloc((sizeof(struct ordertype))*n);
    for (j=0;j<n;j++)
    {
        (ro+j)->val = (double)(o+j)->order;
        (ro+j)->order = j+1;
    }
    qsort(ro,n,sizeof(struct ordertype),cmp_ordertype_by_val);
#endif
    po = (struct ordertype *)malloc((sizeof(struct ordertype))*n);
    for (j=0;j<n;j++)
    {
        (po+j)->val = (double)pvals[j];
        (po+j)->order = (o->order); // why the hell isn't this ro? what the what?
    }
    qsort(po,n,sizeof(struct ordertype),cmp_ordertype_by_val_REV); // == p[o]

    cummin = (struct ordertype *)malloc((sizeof(struct ordertype))*n); // holds n / i * po
    for (j=0;j<n;j++)
    {
        (cummin+j)->val = (double)n / (double)(i+j)->order * ((po+j)->val) ;
    }
                   // Rcode: pmin(1, cummin( n / i * p[o] ))[ro]           ******************
    for (j=1;j<n;j++)
    {
        if ((cummin+j)->val > (cummin+j-1)->val)
            (cummin+j)->val = (cummin+j-1)->val;
    }
    for (j=0;j<n;j++)
    {
        if ((cummin+j)->val > 1)
            (cummin+j)->val = 1;
        (cummin+j)->order = (o+j)->order ;
    }
    qsort(cummin,n,sizeof(struct ordertype),cmp_ordertype_by_order);
#if RDEBUG
FILE *fp2;
fp2 = fopen("test.fdrs","w");
#endif
    for (j=0;j<n;j++)
    {
        returnpvals[j] = (cummin+j)->val;
#if RDEBUG
fprintf(fp2,"%20.18f\n",returnpvals[j]);
#endif
    }
#if RDEBUG
fclose(fp2);
#endif
    if (i) free(i);
    if (o) free(o);
    if (po) free(po);
    if (cummin) free(cummin);

    return;
}

// modified from  Darel Rex Finley https://alienryderflex.com/quicksort/ - public domain
static inline int quickSort(unsigned int *arr, int elements) 
{
  #define  MAX_LEVELS  1000

  int  piv, beg[MAX_LEVELS], end[MAX_LEVELS], i=0, L, R ;

  beg[0]=0; end[0]=elements;
  while (i>=0) 
  {
    L=beg[i]; R=end[i]-1;
    if (L<R) {
      piv=arr[L]; if (i==MAX_LEVELS-1) return -1;
      while (L<R) 
      {
        while (arr[R]>=piv && L<R) 
            R--; 
        if (L<R) arr[L++]=arr[R];
        while (arr[L]<=piv && L<R) 
            L++; 
        if (L<R) arr[R--]=arr[L]; 
      }
      arr[L]=piv; beg[i+1]=L+1; end[i+1]=end[i]; end[i++]=L; }
    else {
      i--; }
  }
  return 0; 
}
static inline void subsamp(unsigned int s[], int n, int k)
{
    int i,j,dncnt;;
    unsigned int  ui;

// fprintf(stderr,"in subsamp %d %d\n",n,k); fflush(stderr);
    for (dncnt=n,i=0;i<k;i++,dncnt--)
    {
// fprintf(stderr,"in subsamp i=%d dncnt=%d\n",i,dncnt); fflush(stderr);
        j = (rand() % dncnt) + i;
        ui = s[i];
        s[i] = s[j];
        s[j] = ui;
    }
// fprintf(stderr,"end subsamp %d %d\n",n,k); fflush(stderr);
    return;
}

#define NUM_PERMUTES 1000
int permute(int idx,struct used_path_type *uptr,unsigned int real_universe_cnt,unsigned int *real_universe, int ingenecnt)
{
    unsigned int r[40002];
    double   p[NUM_PERMUTES];
    int i,j,k;
    double d;
    int tmphitcnt;
    unsigned int ui_uk,ui_ej;

// fprintf(stderr,"in permute idx %d %s r=%p\n",idx,uptr->name,r); fflush(stderr);
    memcpy(r,real_universe,real_universe_cnt*sizeof(unsigned int));
// fprintf(stderr,"in permute idx after memcpy\n"); fflush(stderr);
    for (i=0;i<NUM_PERMUTES;i++)
    {
// fprintf(stderr,"in permute idx i=%d, real_universe_cnt=%d in=%d\n",i,real_universe_cnt,ingenecnt); fflush(stderr);
        subsamp(r, real_universe_cnt,ingenecnt); // inlined if optimization on 
// fprintf(stderr,"in permute idx i=%d 1 \n",i); fflush(stderr);
        quickSort(r,ingenecnt); // inlined if optimization on 
// fprintf(stderr,"in permute idx i=%d 2 \n",i); fflush(stderr);
#if 0
fprintf(stderr,"r ingenecnt=%d\n",ingenecnt); 
for (j=0;j<ingenecnt;j++) fprintf(stderr,"%u ",*(r+j));
fprintf(stderr,"\n"); 
fprintf(stderr,"egids\n"); 
for (j=0;j<uptr->numfixedgenes;j++) fprintf(stderr,"%u ",*(uptr->egids+j));
fprintf(stderr,"\n"); 
#endif
// fprintf(stderr,"in permute idx i=%d 3 \n",i); fflush(stderr);
        j = k = tmphitcnt = 0;
//  fprintf(stderr,"in permute %s %d 4\n",uptr->name,i); fflush(stderr);
        while ((j<uptr->numfixedgenes) && (k < ingenecnt))
        {
            ui_ej = *(uptr->egids+j);
            ui_uk = *(r+k);
            if (ui_ej == ui_uk)
            {
                tmphitcnt++;
                k++;
                j++;
                continue;
            }
            else if (ui_ej < ui_uk) j++;
            else                    k++;
        }
        d = exact22((int)tmphitcnt,uptr->numfixedgenes,ingenecnt,real_universe_cnt);
// fprintf(stderr,"%d %d %d exact22(%d %d %d %d)\n",i,k,j,tmphitcnt,uptr->numfixedgenes,ingenecnt,real_universe_cnt); 
        p[i] = d;
    }
    qsort(p,NUM_PERMUTES,sizeof(double),cmp_double);
    d = 1.0;
    for (j=0;j<NUM_PERMUTES;j++) 
    {
        if (p[j] > uptr->pval) { d = p[j]; break; }
    }
    d = (double)j/(double)NUM_PERMUTES;
    uptr->fdr =  d;
    uptr->fdr2 = d;
    return 0;
}



int do_pvals_and_bh(unsigned int ingenecnt, struct used_path_type usedpaths[], unsigned int numusedpaths,unsigned int real_universe_cnt,unsigned int *real_universe)
{
    double pv;
    double ad;
    int i;
    double *pvals;
    double *fdrs;
    unsigned int localhitcnt ;
    struct used_path_type *uptr; // used path pointer 

    pv = 1.0;
    pvals = (double *)malloc((size_t)(sizeof (double)*(numusedpaths)));
    if (!pvals) { fprintf(stderr,"ERROR: no memory\n"); return -1; }
    for (i=0 ; i<numusedpaths;i++)
    {
        uptr = (usedpaths+i);
        localhitcnt = uptr->hitcnt;
        if (localhitcnt)
        {
            if (localhitcnt > (unsigned int)uptr->numfixedgenes) 
            {
                 fprintf(stderr,"ERROR: more hits than genes (localhitcnt %d > %d for %s)\n", 
                         localhitcnt , uptr->numfixedgenes,uptr->acc);
                 fprintf(stderr,"details: index=%d , hitcnt=%u\n", i,localhitcnt); 
                 fflush(stderr);
                 return -2;
            }
        }
// fprintf(stderr,"in dopvals path=%d \n",i);  fflush(stderr); ;
// test ...
//d = exact22(n11_,n12_,n21_,n22_); note:3 hits in p53 pathway which has  40 genes ,total 29960 genes , user input 300 genes 
// d = exact22(3,40,297,29960);
#if NELSON
/*
A = u - p - h
B = u - l 
C = l - h 
D = h
*/
int u,p,h,l,a,b,c,d;
u = real_universe_cnt;
p = uptr->numfixedgenes;
h = localhitcnt;
l = ingenecnt;
a = u - p - h;
b = u - l;
c = l - h;
d = h;

        pv = exact22(a,b,c,d);
        ad = ( ((double)localhitcnt / (double)uptr->numfixedgenes) - ((double)ingenecnt/(double)real_universe_cnt) );
        *(pvals+i) = uptr->pval = pv;
        uptr->a = a;
        uptr->b = b;
        uptr->c = c;
        uptr->d = d;
        uptr->ad = ad;
#else
/*
     4  pwhitcount            number of genes hit in pathway
     5  pwnohitcount          pathway    number of genes in the pathway
     6  inputlist                  total count of user genes (user input)
     7  pwuniverseminuslist    tinlistpathwaysuniverse    total number of unique genes in all pathways
a=hits
b=thispw-hits
c=list
d=u-list
*/
int a,b,c,d;
        a = localhitcnt;
        b = uptr->numfixedgenes - localhitcnt;
        c = ingenecnt;
        d = real_universe_cnt - ingenecnt;

        pv = exact22(a,b,c,d);
        uptr->pval = *(pvals+i) = pv;
        uptr->a = a;
        uptr->b = b;
        uptr->c = c;
        uptr->d = d;
        // ad = ( ((double)localhitcnt / (double)uptr->numfixedgenes) - ((double)ingenecnt/(double)real_universe_cnt) );
        ad = ( ((double)a / (double)b) - ((double)c/(double)d) );

        uptr->ad = ad;
#endif
    }

    fdrs = (double *)malloc((size_t)(sizeof (double)*numusedpaths)); 
    if (!fdrs) { free(pvals); /* clean up */ fprintf(stderr,"ERROR: no memory in do_pvals_and_bh() 2\n"); return -3; }

    benjaminihochberg(numusedpaths,pvals,fdrs);
    for (i=0 ; i<numusedpaths ; i++)
    {
         usedpaths[i].fdr = *(fdrs+i);
// fprintf(stderr,"%d %f\n", i,usedpaths[i].fdr);
    }
    free(pvals);
    free(fdrs);
    return 0;
}

#if L2PUSETHREADS
#define NUM_THREADS 8
int permute_range( int num_used_paths,struct used_path_type usedpaths[],unsigned int real_universe_cnt,unsigned int *real_universe, int ingenecnt, int lo, int hi)
{
    int i;

    for (i=lo ; i<=hi ; i++)
    {
// fprintf(stderr, "%d from %d to %d of %d %s \n",i,lo,hi,num_used_paths,usedpaths[i].name); fflush(stderr); 
        permute(i,&usedpaths[i],real_universe_cnt,real_universe,ingenecnt);
    }
    return 0;
}

struct thread_data_t {
    int tid;
    int myid;
    int lo;
    int hi;
    unsigned int ingenecnt;
    struct used_path_type *usedpaths;
    unsigned int numusedpaths;
    unsigned int real_universe_cnt;
    unsigned int *real_universe;
};

/* thread function */
void *thr_func(void *arg) 
{
  struct thread_data_t *data = (struct thread_data_t *)arg;
  fprintf(stderr,"hello from thr_func, thread id: %d %d %d, myid=%d\n", data->tid , data->lo , data->hi ,data->myid); fflush(stderr);
  permute_range(data->numusedpaths,data->usedpaths,data->real_universe_cnt,data->real_universe, data->ingenecnt, data->lo,data->hi);
//   sleep(rand() % 3); 
  pthread_exit(NULL);
}


int threaded_permutes(unsigned int ingenecnt, struct used_path_type usedpaths[], unsigned int numusedpaths,unsigned int real_universe_cnt,unsigned int *real_universe)
{
    pthread_t thr[NUM_THREADS];
    struct thread_data_t thr_data[NUM_THREADS];
    int i;
    int rc;
    int k;

fprintf(stderr,"in threaded_permutes()\n"); fflush(stderr); 
    k = numusedpaths/NUM_THREADS;
    for (i = 0; i < NUM_THREADS; ++i) 
    {     /* create threads */
        thr_data[i].lo = i*k;
        thr_data[i].hi = (i*k)+k-1;
        if (i == (NUM_THREADS-1))
            thr_data[i].hi = numusedpaths-1; // note "-1", 
fprintf(stderr,"%d of %d [ %d .. %d ] of %d size= %d\n",i,NUM_THREADS,thr_data[i].lo,thr_data[i].hi,numusedpaths,thr_data[i].hi-thr_data[i].lo); 
        thr_data[i].myid = i;
        thr_data[i].ingenecnt = ingenecnt;
        thr_data[i].usedpaths = usedpaths;
        thr_data[i].numusedpaths = numusedpaths;
        thr_data[i].real_universe_cnt = real_universe_cnt;
        thr_data[i].real_universe = real_universe;
fprintf(stderr,"creating thread %d\n",i); fflush(stderr); 
        if ((rc = pthread_create(&thr[i], NULL, thr_func, &thr_data[i]))) 
        {
          fprintf(stderr, "error: pthread_create, rc: %d\n", rc);
          return EXIT_FAILURE;
        }
    }
  /* block until all threads complete */
    for (i = 0; i < NUM_THREADS; ++i) 
    {
fprintf(stderr,"blocking %d \n",i);
        pthread_join(thr[i], NULL);
    }
fprintf(stderr,"after blocking  \n");
  return EXIT_SUCCESS;
}
#endif

 

          /* Be srue to free egids if you call this !!! */
int setup_by_egids(void)
{
    size_t sz = sizeof(struct smallgenetype) * numgenes;

    by_egids = (struct smallgenetype *)malloc(sz);
    if (!by_egids) return -1;
    memcpy(by_egids,genes,sz);
    qsort(by_egids,numgenes,sizeof(struct smallgenetype),cmp_by_egid);
    return 0;
}


#define MAX_INGENES 40000
unsigned int  ingenes[MAX_INGENES];
unsigned int  tmpgenes[MAX_INGENES];
 
int l2pfunc(struct used_path_type *usedpaths,int num_used_paths,unsigned int real_universe_cnt,unsigned int *real_universe, int precise_flag, int permute_flag, int *user_incnt_ptr)
{
    char s[512];
    struct used_path_type *uptr; // used path pointer 
    unsigned int prev;
    unsigned int ui;
    unsigned int ui_ej;
    unsigned int user_incnt = 0;
    int i,j,k,ll;
    int ret = 0;
    int overflowflag = 0;
    unsigned int *uiptr = (void *)0;
// struct timespec time1, time2;
    // char *z;

    *user_incnt_ptr = j = 0;
    while ( fgets(s, sizeof(s), stdin) ) // gets() function is deprecated
    {
        for (i=0 ; s[i] ; i++) 
        { 
             if ((s[i] == '\n')||(s[i] == '\r')) s[i] = (char)0; 
             else if ((s[i] < ' ') || (s[i] >= 127)) s[i] = ' ';
        }
        ui = hugo2egid(s);
        if (ui == (unsigned int)UINT_MAX)
        {
             fprintf(stderr,"Note: invalid gene \"%s\" in user input\n",s);  
             continue;
        }
        uiptr = (unsigned int *)bsearch(&ui,real_universe,real_universe_cnt,sizeof(unsigned int),cmp_ui);
        if (!uiptr)
        {
             fprintf(stderr,"Note: gene not in universe : \"%s\" \n",s);  
             continue;
        }
        if (j < MAX_INGENES)
        {
            tmpgenes[j++] = ui;
        }
        else
        {
            if (overflowflag == 1) { fprintf(stderr,"NOTE: too many genes, input gene number limited to %d, rest are ignored, incnt=%d\n",MAX_INGENES,j); fflush(NULL); }
            overflowflag = 1;
        }
    }
    qsort(tmpgenes,j,sizeof(unsigned int),cmp_ui); // sort user input egids
    prev = 0;
    for (i=user_incnt=0;i<j;i++)
    {
        ui = tmpgenes[i];
        if (ui != prev)
        {
            ingenes[user_incnt++] = ui;
        }
        prev = ui;
    }
    
// clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &time1);


    for (i=0 ; i<num_used_paths ; i++)
    {
        uptr = (usedpaths+i);
        if (!uptr->egids) continue;
        j = k = ll = 0;
        while ((j<uptr->numfixedgenes) && (k < user_incnt))
        {
            ui_ej = *(uptr->egids+j);
            ui = ingenes[k];
            if (ui_ej == ui)
            {
                *((uptr->genehits) + (ll++)) = ui; // remember, because need to print out later
                k++;
                j++;
                continue;
            }
            else if (ui_ej < ui) j++;
            else                    k++;
        }
        uptr->hitcnt = ll;
    }
#if 0
clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &time2);
#define BILLION  1000000000.0;
double time_spent = (time2.tv_sec - time1.tv_sec) + (time2.tv_nsec - time1.tv_nsec) / BILLION;
fprintf(stderr,"Time elapsed is %f seconds\n", time_spent);  fflush(NULL);

fprintf(stderr,"here , before do_pvals %d %d %p %d \n",real_universe_cnt , user_incnt, usedpaths,num_used_paths); 
fflush(NULL);
#endif

    do_pvals_and_bh(user_incnt, usedpaths,num_used_paths,real_universe_cnt,real_universe);

    *user_incnt_ptr = user_incnt;
     if (permute_flag)
     {
#if L2PUSETHREADS 
dont uue thread
         int threads = 0;
         if (threads) threaded_permutes(user_incnt,usedpaths,num_used_paths,real_universe_cnt,real_universe);
#else
         for (i=0 ; i<num_used_paths ; i++)
         {
             (void)permute(i,&usedpaths[i],real_universe_cnt,real_universe,user_incnt);
if ((i%1000) == 0) fprintf(stderr,"fdr %d of %d fdr2: %f fdr: %f\n",i,num_used_paths,usedpaths[i].fdr2,usedpaths[i].fdr);
         }
#endif
 }
    return ret;
}




#ifdef WEBASSEMBLY
// need to bring in for wasm
int testwasm(void)
{
int i;
for (i=0;i<10;i++) printf("%s",genes[i].hugo); // wasm 
for (i=0;i<10;i++) printf("%s",pws[i].name); // wasm 
for (i=0;i<10;i++) printf("%d",pwgenes[i]); // wasm 
return 0;
}
#else
void usage(void)
{
fprintf(stderr,"l2p : \"list to pathways\" program.\n");
fprintf(stderr,"Usage: cat listofHUGOgenes_one_per_line.txt | l2p [optional args]\n");
fprintf(stderr,"possible optional args are ...\n");
fprintf(stderr," -help\n");
fprintf(stderr," -precise\n");
fprintf(stderr," -noheader\n");
fprintf(stderr," -universe=Universefile_one_gene_per_line.txt\n");
fprintf(stderr," -categories=listofcatgories  (comma separated)\n");
fprintf(stderr,"    example: -categories=KEGG,REACTOME,BIOCYC,PANTH  (i.e. only use genes in those 4 categories\n");
fprintf(stderr,"    another -categories example: \"-categories=H,C6\"  (i.e. only use msigdb's Hallmark and C6 (cancer) category pathways\n");
fprintf(stderr,"    available categories are :\n");
fprintf(stderr,"    BIOCYC  - organism specific Pathway/ Genome Databases (PGDBs)  - https://biocyc.org/\n");
fprintf(stderr,"    GO  - initiative to unify representation of gene and gene product attributes -  http://geneontology.org\n");
fprintf(stderr,"    KEGG - databases dealing with genomes, biological pathways, - https://www.kegg.jp/\n");
fprintf(stderr,"    PANTH - databases for protein analysis through evolutionary relationships - http://www.pantherdb.org/\n");
fprintf(stderr,"    PID  - Pathway interaction database: legacy database from Carl Schaefer & buddies at NCI\n");
fprintf(stderr,"    REACTOME - curated database of biological pathways - https://reactome.org/\n");
fprintf(stderr,"    WikiPathways - community resource for biological pathways - https://www.wikipathways.org\n");
fprintf(stderr,"    C1 - MSigDB only, positional gene sets for each human chromosome and cytogenetic band.\n");
fprintf(stderr,"    C2 - MSigDB only, curated gene sets from online pathway databases, publications in PubMed, and experts.\n");
fprintf(stderr,"    C3 - MSigDB only, motif gene sets based on conserved cis-regulatory motifs from comparative analysis\n");
fprintf(stderr,"    C4 - MSigDB only, computational gene sets defined by mining large collections of cancer-oriented microarray data.\n");
fprintf(stderr,"    C5 - MSigDB only, gene sets  consist of genes annotated by the same GO terms.\n");
fprintf(stderr,"    C6 - MSigDB only, oncogenic gene sets defined directly from microarray data from cancer gene perturbations.\n");
fprintf(stderr,"    C7 - MSigDB only, immunologic gene sets  from microarray data from immunologic studies.\n");
fprintf(stderr,"    H - MSigDB only, hallmark gene sets: signatures from MSigDB gene sets to represent biological processes.\n");
fprintf(stderr,"Example run : printf \"TP53\\nPTEN\\nAPC\\nKRAS\\nNRAS\\n\" | ./l2p -categories=PID | sort -k2,2n -k1,1n -k3,3nr | head\n");
            fflush(NULL);
}

int bitCount(int n)
{
    int cnt = 0;
    while (n)
    {
        cnt += n % 2;
        n >>= 1;
    }
    return cnt;
}

static int parsecats(char *z, unsigned int *catspat)
{
    char ts[16][16];
    int bit;
    int j,k;
    int toks;

    for (j=0 ; *(z+j) ; j++)
    {
        if (*(z+j) == ',') *(z+j) = ' ';
    }
    memset(ts,0,sizeof(ts));
    toks = sscanf(z,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s ",
          ts[0], ts[1], ts[2], ts[3], ts[4], ts[5], ts[6], ts[7], ts[8], ts[9],
          ts[10], ts[11], ts[12], ts[13], ts[14], ts[15]);
    for (k=0;k<toks;k++)
    {
        bit=string_to_category_code(ts[k]);
        if (bit)
            *catspat |= bit;
        else
        {
            fprintf(stderr,"ERROR: invalid category = %s\n",ts[k]);
            usage();
            exit(0);
        }
    }
    j = bitCount(*catspat) ;
    if (j == 0)
    {
#ifdef L2P_USING_R
        return 0;
#else
        fprintf(stderr,"ERROR: no categories specified\n");
        usage();
        return -1;
#endif
    }
    return 0;
}



int l2p_init_C(int Rflag,int argc,char *argv[],unsigned int *catspatptr,int *precise_flag, int *permute_flag,int *no_header_flag, char universe_file[], char custom_file[], int *get_universe_flag)
{
    char *z;
    int i;

    *get_universe_flag = 0;
    *precise_flag = 0;
    *permute_flag = 0;
    *no_header_flag = 0;
    universe_file[0] = (char)0;
    custom_file[0] = (char)0;
    for (i=1 ; i<argc ; i++)
    {
        if ((strcmp(argv[i],"-help") == 0) || (strcmp(argv[i],"--help") == 0) || ((strcmp(argv[i],"help") == 0) ) )
        {
             usage();
             exit(1);
        }
        else if (strncmp(argv[i],"-categories=",12) == 0)
        {
            z = argv[i],
            z += 12;
            parsecats(z,catspatptr);
        }
        else if (strcmp(argv[i],"-precise") == 0)
              *precise_flag = 1; // print more digits out some user doesn't complain about "real pvals"
        else if (strcmp(argv[i],"-permute") == 0)
              *permute_flag = 1; // print more digits out some user doesn't complain about "real pvals"
        else if (strcmp(argv[i],"-noheader") == 0)
              *no_header_flag = 1;
        else if (strncmp(argv[i],"-universe=",10) == 0)
        {
            strcpy(universe_file,argv[i] + 10);
            // user_universe_flag = 1;
fprintf(stderr,"note: using \"%s\" as universe file\n",universe_file);
        }
        else if (strcmp(argv[i],"-getuniverse") == 0)
        {
            *get_universe_flag = 1;
        }
        else if (strncmp(argv[i],"-customfile=",12) == 0)
        {
            strcpy(custom_file,argv[i] + 12);
//             customflag++;
fprintf(stderr,"note: using \"%s\" as custom pathway gene listfile\n",custom_file);
        }
        else 
        {
fprintf(stderr,"Note: Invalid argument \"%s\" : ignored.\n",argv[i]);
        }
    }
    if (*catspatptr == 0) category_set_all(catspatptr);
    return 0;
}


void do_get_universe(unsigned int real_universe_cnt, unsigned int *ru)
{
    int i;
    char *z;
fprintf(stderr,"in do_get_universe real_universe_cnt = %d \n",real_universe_cnt);  fflush(stderr); 
    for (i=0;i<real_universe_cnt;i++)
    {
        z = egid2hugo(*(ru+i));
        if (z) printf("%s\n",z);
    }
    return;
}


unsigned int *get_used_universe(struct used_path_type *u, unsigned int num_used, unsigned int *real_universe_cnt_ptr)
{
    int i,j,k;
    size_t sz = 0;
    unsigned int prev = 0;
    unsigned int ui = 0;
    unsigned int maxelems = 0;
    unsigned int *tempverse  = (unsigned int *)0;
    unsigned int *real_universe  = (unsigned int *)0;
    struct used_path_type *uptr = (void *)0;    // used path pointer


    if (!u)
    {
        fprintf(stderr,"ERROR: null used_path_type passed to get_used_universe()\n"); fflush(stderr); 
        return (unsigned int *)0 ;
    }

    maxelems = numpwgenes * 2;
    sz = (maxelems * sizeof(unsigned int)); //  maximum possible number of genes
    tempverse = malloc(sz);
    if (!tempverse)
    {
        fprintf(stderr,"ERROR: not enough memory in get_used_universe()\n"); fflush(stderr); 
        return (unsigned int *)0 ;
    }
    memset(tempverse,0,sz);
    for (i=k=0;i<num_used;i++)
    {   
        uptr = (u+i);
        for (j=0 ; j < uptr->numfixedgenes ; j++)
        {
            *(tempverse+k) = *(uptr->egids + j);
            k++;
            if (k >= maxelems)
            {
fprintf(stderr,"in get_used_universe ERROR i=%d k=%d\n",i,k);  fflush(stderr); 
exit(0);
            }
        }
    }
    qsort(tempverse,k,sizeof(unsigned int),cmp_ui);
    real_universe = (unsigned int *)malloc(sizeof(unsigned int) * numgenes);
    prev = 0;
    for (i=j=0;i<k;i++)
    {
       ui = *(tempverse+i); 
       if (ui != prev)
       {
           *(real_universe+j) = ui;
           j++;
       }
       prev = ui;
    }
    *real_universe_cnt_ptr = j;
    free(tempverse);
    return (void *)real_universe;
}


unsigned int *load_user_universe_file(char universe_file[], unsigned int *universe_cnt_ret)
{
    char s[130000];   // 127570 is number of bytes in universe file, so should handle anything
    unsigned int ui;
    FILE *universe_fp;
    unsigned int *universe_genes = (unsigned int *)0;
    unsigned int universe_cnt;
    int i,j;

    *universe_cnt_ret = j = 0;
    if (universe_file[0])
    {                 // we have a universe file
        universe_fp = fopen(universe_file,"r");
        if (!universe_fp) 
        {
fprintf(stderr,"ERROR: Can't open universe_file named \"%s\"\n",universe_file); 
            return (void *)0;
        }
        universe_cnt = 0;
        while ( fgets(s, sizeof(s), universe_fp) )
            universe_cnt++;
        universe_genes = malloc(sizeof(unsigned int *)*universe_cnt);
        rewind( universe_fp);
        j = 0;
        while ( fgets(s, sizeof(s), universe_fp) )
        {
            for (i=0 ; s[i] ; i++) { if ((s[i] == '\n')||(s[i] == '\r')) s[i] = (char)0; }
// if (ui==29974) { fprintf(stderr,"got A1CF 29974\n"); exit(0); }
            ui = hugo2egid(s);
            if (ui == (unsigned int)UINT_MAX)
            {
                fprintf(stderr,"Note: invalid gene \"%s\" in universe file.\n",s);  
                continue;
            }
            *(universe_genes+j) = ui;
            j++;
        }
        fclose (universe_fp);
    }
    qsort(universe_genes,j,sizeof(unsigned int),cmp_ui);
    *universe_cnt_ret = j; // repair this , some genes may have been "invalid". initial count may have been wrong.
    return universe_genes;
}

 
int count_lines_in_file(char *fn)
{
    FILE *fp;
    int lines = 0;
    int ch = 0;

    fp = fopen(fn,"r");
    if (!fp) return 0;
    while(!feof(fp))
    {
        ch = fgetc(fp);
        if (ch == '\n') lines++;
    }
    fclose(fp);
    return lines;
}


struct used_path_type *setup_used_paths(int *num_used_paths, unsigned int catspat, char universe_file[], unsigned int in_universe_cnt,unsigned int *in_universe, char custom_file[], unsigned int *real_universe_cnt_ptr,unsigned int **real_universe,int lencust,struct custom_type *mycustompw)
{
	char s[100000];
	char tmps[5120];
	char custname[5120];
	int i,j,k,ll,used_index,tokcnt;
	struct custom_type *kust = (struct custom_type *)0;
	char *z = (void *)0;
	int this_cust_pw_cnt = 0;
	unsigned int ui = 0;
	unsigned int *uiptr = (void *)0;
	unsigned short int usi = (unsigned short int)0;
	struct used_path_type *u = (struct used_path_type *)0;
	struct used_path_type *uptr; // used path pointer
	unsigned int custom_cnt = 0;
	unsigned int universe_cnt = 0;
	unsigned int *user_universe_genes = (unsigned int *)0;
	unsigned int *this_egids = (unsigned int *)0;
	unsigned int *tmpugenes = (unsigned int *)0;;
	unsigned int prev = 0;
	int newcnt = 0;
	int keepgoing;
	FILE *fp;
	//     char **custom_data = (void *)0;
	// struct timespec time1, time2;

	// clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &time1);
// fprintf(stderr,"in setup_used_paths() start catspat=%d = 0x%x\n",catspat,catspat); fflush(stderr); 
              // just need to know how many lines in gmt file
    *real_universe = (unsigned int *)0;

    custom_cnt = count_lines_in_file(custom_file);

// fprintf(stderr,"xxx in_unvser_cnt = %d\n",in_universe_cnt); fflush(stderr); 
    if (universe_file[0])
    {
        user_universe_genes = load_user_universe_file(universe_file,&universe_cnt); // may return null 
    }
    else if (in_universe_cnt != 0)
    {
        user_universe_genes = in_universe;
	universe_cnt = in_universe_cnt;
// fprintf(stderr,"xxx in in_unvser_cnt = %d  %p\n",in_universe_cnt,in_universe); fflush(stderr); 
    }
    u = (struct used_path_type *)malloc(sizeof(struct used_path_type) * (numpws+custom_cnt+lencust));
    if (!u) { fprintf(stderr,"ERROR: not enough memory.\n"); return (void *)0; }

    used_index = 0;
    for (i=0 ; i<numpws ; i++)
    {
// fprintf(stderr,"in setup_used_paths() 3.1, numpws=%d\n",numpws); fflush(stderr); 
        if ((pws[i].category & catspat) == 0) continue;
        this_egids = (unsigned int *)malloc(sizeof(unsigned int)*pws[i].numgenes);
        if (universe_cnt)   // get rid of unused genes - use only universe genes
        {
// fprintf(stderr,"xxx in universe_cnt = %d i=%d to %d\n",universe_cnt,i,numpws); fflush(stderr); 
            for (newcnt = j = 0 ; j<pws[i].numgenes ; j++)
            {
                usi = pwgenes[pws[i].pwgenesindex+j];
                ui = genes[usi].egid;
                uiptr = (unsigned int *)bsearch(&ui,user_universe_genes,universe_cnt,sizeof(unsigned int),cmp_ui);
                if (uiptr)
                {
                    *(this_egids+newcnt) = ui; // put this in the right place
                    newcnt++;
                }
                else
                {
// fprintf(stderr,"missed %s ui = %u , usi=%u uu=%p uucnt=%d, and checked=%d\n",zzz,ui,(unsigned int)usi,user_universe_genes,universe_cnt,universe_cnt);
                }
            }
            if (newcnt < 3)  // not enough genes
            {
                free(this_egids);
                this_egids = (unsigned int *)0;
                continue;
            }
        }
        else
        {
            for (newcnt = j = 0 ; j<pws[i].numgenes ; j++)
            {
                ll = pwgenes[pws[i].pwgenesindex + j];
                if (ll == USHRT_MAX) // masked out as not in universe
                {
fprintf(stderr,"ERROR: %u \n",ll); exit(0);
                    continue;
                }
                *(this_egids+newcnt) = genes[ll].egid;
                newcnt++;
            }
        }
        uptr = (u+used_index);

        qsort(this_egids,newcnt,sizeof(unsigned int),cmp_ui);
        uptr->egids = this_egids;
        uptr->numfixedgenes = newcnt;
        uptr->genehits = (unsigned int *)malloc(sizeof(unsigned int)*newcnt);
        uptr->category = pws[i].category;
        uptr->acc  = strdup(pws[i].acc);       // can't just assign (?)  . because need to free if custom
        uptr->name = strdup(pws[i].name);      // can't just assign
        uptr->numgenes = pws[i].numgenes;
        uptr->pwgenesindex = pws[i].pwgenesindex; // not going to care about this probably. info is now in egids
        uptr->hitcnt = 0;
        used_index++;
    }

#define MAXUGENES 40000
    if (custom_cnt)
    {
        if (tmpugenes) { free(tmpugenes); tmpugenes = (unsigned int *)0; }
        tmpugenes=malloc(sizeof(unsigned int)*MAXUGENES);
        if (!tmpugenes) { fprintf(stderr,"can't malloc %u bytes \n",(unsigned int)(sizeof(unsigned int)*MAXUGENES));  fflush(stderr); }
    fp = fopen(custom_file,"r");
    if (!fp) { fprintf(stderr,"NOTE: can not open \"%s\" - ignoring\n",custom_file); fflush(stderr); }
    while ( fgets(s, sizeof(s)-2, fp) ) // for each line of custom file
    {
        for (k=0 ; s[k] ; k++) { if ((s[k] == '\n')||(s[k] == '\r')) s[k] = (char)0; } // strip newline
        uptr = (u+used_index); // used_index points to next available slot 
        z = &s[0];
        j = tokcnt = k = 0;
        tmps[0] = (char)0;
        keepgoing = 1;
        newcnt = 0;
        while (keepgoing == 1)
        {
            if ( (*(z+j) == '\t') || (*(z+j) == (char)0) )
            {   // first token is name, 2nd is opttional and rest are gene names separated by tabs
               if (tokcnt == 0) strcpy(custname,tmps); 
               else if (tokcnt == 1) { /* ignore */ } 
               else
               {
                   if (tmps[0])
                   {
                       ui = hugo2egid(tmps);
                       if (ui == (unsigned int)UINT_MAX)
                       {
                           fprintf(stderr,"Note: invalid gene \"%s\" in custom pathway file.\n",tmps);  
                       }
                       else
                       {
                           if (universe_cnt) // must be in user universe
                           {
                               uiptr = (unsigned int *)bsearch(&ui,user_universe_genes,universe_cnt,sizeof(unsigned int),cmp_ui);
                               if (uiptr)
                               {
                                   *(tmpugenes+newcnt) = ui; // put this in the right place
                                   newcnt++;
                                   if (newcnt == MAXUGENES) { fprintf(stderr,"ERROR: too many genes on cutom pathway gmt file.\n"); fflush(stderr); }
                               }
                           }
                           else 
                           {
                               *(tmpugenes+newcnt) = ui; // put this in the right place
                               newcnt++;
                           }
                       }
                   }
               }
               tokcnt++;
               k = 0;
               tmps[0] = (char)0;
               if (*(z+j) == (char)0) keepgoing = 0;
            }
            else
            {
                tmps[k++] = *(z+j); 
                tmps[k] = (char)0;
            }
            j++;
        }
        if (newcnt == 0) continue;
        qsort(tmpugenes,newcnt,sizeof(unsigned int),cmp_ui);
        this_cust_pw_cnt = 0;
        prev = 0;
        this_egids = (unsigned int *)malloc(sizeof(unsigned int)*newcnt);
        for (k=0;k<newcnt;k++) // de-duplicate, put only UNIQUE genes in
        {
            ui = *(tmpugenes+k); 
            if (ui != prev)
            {
                *(this_egids+this_cust_pw_cnt) = ui;
                this_cust_pw_cnt++;
            }
            prev = ui;
        }
        uptr->acc = strdup(custname); // remember to free this
        uptr->name =strdup(custname);  // remember to free this
        uptr->egids = this_egids; // remember to free this
        uptr->numgenes = uptr->numfixedgenes = this_cust_pw_cnt;
        uptr->pwgenesindex = USHRT_MAX;
        uptr->genehits = (unsigned int *)malloc(sizeof(unsigned int)*this_cust_pw_cnt); // remember to free this
        uptr->hitcnt = 0;
        uptr->category = CAT_CUSTOM | (string2type("custsom") << 28);
        used_index++;
    }
    if (tmpugenes) { free(tmpugenes); tmpugenes = (unsigned int *)0; }
    }
    for (i=0;i<lencust;i++) // add R user custom lists passed as a list of vectors (with "gmt" lines)
    {
        uptr = (u+used_index); // used_index points to next available slot 
        kust = (mycustompw + i);
        this_egids = (unsigned int *)malloc(sizeof(unsigned int) * kust->numgenes);
        for (j=0 ; j<kust->numgenes ; j++)   // for each line of custom file
        {
            *(this_egids+j) = *(kust->genes+j);
        }
        uptr->acc = strdup(kust->name);
        uptr->name = strdup(kust->name);
        uptr->egids = this_egids; // remember to free this
        uptr->numgenes = uptr->numfixedgenes = kust->numgenes;
        uptr->pwgenesindex = USHRT_MAX;
        uptr->genehits = (unsigned int *)malloc(sizeof(unsigned int)*kust->numgenes);
        uptr->hitcnt = 0;
        uptr->category = CAT_CUSTOM | (string2type("custsom") << 28);
        used_index++;
    }
    *num_used_paths = used_index;
    if (user_universe_genes) free(user_universe_genes);

    *real_universe = get_used_universe(u, used_index, real_universe_cnt_ptr);
#if 0
clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &time2);
#define BILLION  1000000000.0;
double time_spent = (time2.tv_sec - time1.tv_sec) + (time2.tv_nsec - time1.tv_nsec) / BILLION;
fprintf(stderr,"Time elapsed is %f seconds\n", time_spent); 
#endif
    return u;
}

int main(int argc,char *argv[])
{
    char universe_file[PATH_MAX];
    char custom_file[PATH_MAX];
    char tmps[PATH_MAX];
    int user_incnt = 0;
    int no_header_flag = 0;
    int precise_flag = 0;
    int permute_flag = 0;
    unsigned int catspat = 0;
    int num_used_paths;
    struct used_path_type *u;
    struct used_path_type *uptr;
    int status;
    unsigned int *real_universe;
    unsigned int real_universe_cnt;
    int get_universe_flag = 0;
    int i = 0;
    int j = 0;
    char *z;

    (void)setup_by_egids();
    l2p_init_C(0,argc,argv,&catspat,&precise_flag,&permute_flag,&no_header_flag,universe_file,custom_file,&get_universe_flag);
    u = setup_used_paths(&num_used_paths, catspat,universe_file, 0,(void *)0,custom_file,&real_universe_cnt,&real_universe,0,(struct custom_type *)0);
    if (get_universe_flag == 1)
    {
        do_get_universe(real_universe_cnt,real_universe);
        return 0;
    }
    status = l2pfunc(u,num_used_paths,real_universe_cnt,real_universe,precise_flag,permute_flag,&user_incnt);
    for (i=0 ; i<num_used_paths ; i++)
    {
       uptr = (u+i);
       categories_pattern_to_strings(uptr->category,tmps);
       printf("%11.9f\t%11.9f\t%11.9f\t%d\t%d\t%d\t%d\t%s\t%s\t%s\t%s\t",
           uptr->pval, uptr->fdr, uptr->ad,
           uptr->a, uptr->b, uptr->c, uptr->d,
           uptr->acc, tmps,
           uptr->name, type2string(uptr->category >> 28));
       for (j=0 ; j<uptr->hitcnt ; j++)
       {
           z = egid2hugo(*((uptr->genehits)+j));
           printf("%s ",z);
       }
       printf("\n");
    }

    if (u) 
    {
        for (i=0 ; i<num_used_paths ; i++)
        {
           uptr = (u+i);
           if (uptr->genehits) { free(uptr->genehits); uptr->genehits = (unsigned int *)0; }
           if (uptr->egids)    { free(uptr->egids);    uptr->egids = (unsigned int *)0; }
           if (uptr->acc)      { free(uptr->acc);      uptr->acc = (char *)0; }
           if (uptr->name)     { free(uptr->name);     uptr->name = (char *)0; }
        }
        free(u);
    }
    if (by_egids) free(by_egids);
    return status;
}
#endif

